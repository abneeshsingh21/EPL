"""
EPL - English Programming Language CLI (v7.0)
Standalone command-line interface for the EPL programming language.

This is the primary entry point for the `epl` command.
Usage:
    epl run <file.epl>           Run an EPL program
    epl new <name>               Create a new EPL project
    epl build <file.epl>         Compile to native executable
    epl test [dir|file]          Run tests
    epl repl                     Interactive REPL
    epl install <package>        Install a package
    epl serve <file.epl>         Start production server
    epl <file.epl>               Shorthand for 'epl run'
    epl --version                Show version
    epl --help                   Show help
"""

import sys
import os

# Python version guard
if sys.version_info < (3, 9):
    print(f"EPL requires Python 3.9 or later (found {sys.version_info.major}.{sys.version_info.minor}).")
    print("Please upgrade Python: https://python.org/downloads/")
    sys.exit(1)

# Ensure EPL root is on the path
_EPL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _EPL_ROOT not in sys.path:
    sys.path.insert(0, _EPL_ROOT)

from epl import __version__

# ─── ANSI Colors ──────────────────────────────────────────

def _color(code, text):
    if os.environ.get('NO_COLOR') or not sys.stdout.isatty():
        return text
    return f"\033[{code}m{text}\033[0m"

def _bold(t):    return _color('1', t)
def _green(t):   return _color('32', t)
def _cyan(t):    return _color('36', t)
def _yellow(t):  return _color('33', t)
def _red(t):     return _color('31', t)
def _dim(t):     return _color('2', t)


# ─── Banner ───────────────────────────────────────────────

BANNER = f"""\
{_bold('EPL')} - English Programming Language {_dim(f'v{__version__}')}
Write code in plain English. Build anything.
"""

HELP = f"""\
{_bold('EPL')} - English Programming Language {_dim(f'v{__version__}')}

{_bold('Usage:')}
  epl <file.epl>                   Run an EPL program
  epl run <file.epl> [flags]       Run an EPL program
  epl new <name>                   Create a new EPL project
  epl build <file.epl>             Compile to native executable (.exe)
  epl test [dir|file]              Run EPL test suite
  epl repl                         Start interactive REPL
  epl install <package>            Install a package
  epl uninstall <package>          Remove a package
  epl packages                     List installed packages
  epl modules                      List standard library modules
  epl serve <file.epl> [options]   Start production web server
  epl deploy <target>              Generate deployment configs
  epl fmt <file.epl>               Format EPL source code
  epl lint [dir|file]              Lint EPL source code
  epl docs [dir|file]              Generate API documentation
  epl debug <file.epl>             Debug with breakpoints
  epl js <file.epl>                Transpile to JavaScript
  epl node <file.epl>              Transpile to Node.js
  epl kotlin <file.epl>            Transpile to Kotlin
  epl android <file.epl>           Generate Android project
  epl ir <file.epl>                Show LLVM IR
  epl vm <file.epl>                Run with bytecode VM (fast)
  epl lsp                          Start LSP server for IDE
  epl ai <prompt>                  AI code assistant
  epl gen <description>            AI-generate EPL code
  epl explain <file.epl>           AI-explain what code does

{_bold('Flags:')}
  --strict       Enable static type checking
  --no-color     Disable colored output
  --verbose      Show debug output
  --quiet        Suppress all output except errors
  --sandbox      Disable dangerous builtins

{_bold('Serve Options:')}
  --port N         Server port (default: 8000)
  --workers N      Number of workers (default: 4)
  --reload         Enable hot-reload (dev mode)
  --store TYPE     Store backend: memory|sqlite|redis
  --session TYPE   Session backend: memory|sqlite|redis

{_bold('Package Ecosystem:')}
  epl resolve                      Resolve all dependencies (backtracking)
  epl workspace <cmd>              Workspace/monorepo (init, list, install, validate)
  epl ci [generate|preview]        Generate CI/CD workflows
  epl sync-index [--force]         Sync package index

{_bold('Examples:')}
  epl hello.epl                    Run a program
  epl new myapp                    Create project
  epl build myapp/main.epl         Compile to .exe
  epl test tests/                  Run all tests
  epl serve webapp.epl --reload    Dev server with hot-reload
  epl install github:user/lib      Install package from GitHub
  epl workspace init               Initialize monorepo workspace

{_dim(f'EPL v{__version__} | https://github.com/epl-lang/epl')}
"""


def _print_version():
    print(f"epl {__version__}")


def _print_help():
    print(HELP)


# ─── Project Helpers ──────────────────────────────────────

def _load_project_manifest(path='.'):
    """Load epl.toml/epl.json project metadata if present."""
    from epl.package_manager import load_manifest
    try:
        return load_manifest(path)
    except Exception:
        return None


def _default_project_target():
    """Return the configured project entrypoint, if the current directory is a project."""
    manifest = _load_project_manifest('.')
    if not manifest:
        return None
    return manifest.get('entry') or manifest.get('main') or 'main.epl'


def _resolve_target_args(args):
    """Use the explicit file argument, otherwise fall back to the project manifest entry."""
    if args:
        return list(args)
    target = _default_project_target()
    if target:
        return [target]
    return None


# ─── Command Dispatch ─────────────────────────────────────

def cli_main(argv=None):
    """Main CLI entry point for the `epl` command."""
    if argv is None:
        argv = sys.argv[1:]

    # No args → REPL
    if not argv:
        _run_repl([])
        return 0

    # Global flags
    if '--version' in argv or '-V' in argv:
        _print_version()
        return 0

    if argv[0] in ('--help', '-h', 'help'):
        _print_help()
        return 0

    # Extract global flags
    flags = set()
    clean_args = []
    i = 0
    while i < len(argv):
        if argv[i] in ('--strict', '--no-color', '--verbose', '--quiet', '--sandbox'):
            flags.add(argv[i])
        else:
            clean_args.append(argv[i])
        i += 1

    if '--no-color' in flags:
        os.environ['NO_COLOR'] = '1'

    # Setup logging
    import logging
    if '--verbose' in flags:
        logging.basicConfig(level=logging.DEBUG, format='%(name)s: %(message)s')
    elif '--quiet' in flags:
        logging.basicConfig(level=logging.ERROR, format='%(message)s')
    else:
        logging.basicConfig(level=logging.WARNING, format='%(message)s')

    if not clean_args:
        _run_repl(flags)
        return 0

    command = clean_args[0]
    rest = clean_args[1:]

    # Command dispatch table
    commands = {
        'run':       lambda: _run_file(rest, flags),
        'new':       lambda: _new_project(rest),
        'build':     lambda: _build(rest, flags),
        'compile':   lambda: _build(rest, flags),
        'test':      lambda: _run_tests(rest, flags),
        'repl':      lambda: _run_repl(flags),
        'install':   lambda: _pkg_install(rest),
        'uninstall': lambda: _pkg_uninstall(rest),
        'packages':  lambda: _pkg_list(),
        'modules':   lambda: _list_modules(),
        'init':      lambda: _init_project(rest),
        'search':    lambda: _delegate('search', rest),
        'add':       lambda: _delegate('add', rest),
        'remove':    lambda: _delegate('remove', rest),
        'lock':      lambda: _delegate('lock', rest),
        'update':    lambda: _delegate('update', rest),
        'tree':      lambda: _delegate('tree', rest),
        'outdated':  lambda: _delegate('outdated', rest),
        'audit':     lambda: _delegate('audit', rest),
        'migrate':   lambda: _delegate('migrate', rest),
        'cache':     lambda: _delegate('cache', rest),
        'publish':   lambda: _delegate('publish', rest),
        'info':      lambda: _delegate('info', rest),
        'stats':     lambda: _delegate('stats', rest),
        'serve':     lambda: _serve(rest),
        'deploy':    lambda: _deploy(rest),
        'fmt':       lambda: _format(rest),
        'lint':      lambda: _lint(rest),
        'docs':      lambda: _docs(rest),
        'debug':     lambda: _debug(rest, flags),
        'js':        lambda: _transpile_js(rest),
        'node':      lambda: _transpile_node(rest),
        'kotlin':    lambda: _transpile_kotlin(rest),
        'android':   lambda: _android(rest),
        'ir':        lambda: _show_ir(rest),
        'vm':        lambda: _run_vm(rest, flags),
        'lsp':       lambda: _start_lsp(rest),
        'ai':        lambda: _ai(rest),
        'gen':       lambda: _ai_gen(rest),
        'explain':   lambda: _ai_explain(rest),
        'package':   lambda: _package(rest),
        'cloud':     lambda: _cloud(),
        'train':     lambda: _train(),
        'model':     lambda: _model(),
        'resolve':   lambda: _resolve(),
        'workspace': lambda: _workspace(rest),
        'ci':        lambda: _ci(rest),
        'sync-index': lambda: _sync_index(rest),
    }

    if command in commands:
        try:
            return commands[command]() or 0
        except KeyboardInterrupt:
            print(f"\n{_dim('Interrupted.')}")
            return 130
        except SystemExit as e:
            return e.code if isinstance(e.code, int) else 1
        except Exception as e:
            from epl.errors import EPLError
            if isinstance(e, EPLError):
                print(str(e), file=sys.stderr)
            else:
                print(f"{_red('Error:')} {e}", file=sys.stderr)
            return 1

    # Default: treat as filename
    if command.endswith('.epl') or os.path.isfile(command):
        try:
            return _run_file([command] + rest, flags) or 0
        except KeyboardInterrupt:
            print(f"\n{_dim('Interrupted.')}")
            return 130
        except Exception as e:
            from epl.errors import EPLError
            if isinstance(e, EPLError):
                print(str(e), file=sys.stderr)
            else:
                print(f"{_red('Error:')} {e}", file=sys.stderr)
            return 1

    print(f"{_red('Unknown command:')} {command}")
    print(f"Run {_bold('epl --help')} for usage.")
    return 1


# ─── Run ──────────────────────────────────────────────────

def _run_file(args, flags):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        print("Usage: epl run <file.epl>")
        print("       or run from a directory containing epl.toml / epl.json")
        return 1

    filename = args[0]
    if not os.path.isfile(filename):
        print(f"{_red('Error:')} File not found: {filename}")
        return 1

    from epl.lexer import Lexer
    from epl.parser import Parser
    from epl.interpreter import Interpreter
    from epl.environment import Environment
    from epl.errors import EPLError, set_source_context

    with open(filename, 'r', encoding='utf-8') as f:
        source = f.read()

    set_source_context(source, filename)

    # Optional type checking
    if '--strict' in flags:
        from epl.type_system import TypeChecker
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        program = parser.parse()
        checker = TypeChecker(strict=True)
        diagnostics = checker.check(program)
        errors = [d for d in diagnostics if d.level == 'error']
        warnings = [d for d in diagnostics if d.level == 'warning']
        for d in warnings:
            print(d, file=sys.stderr)
        if errors:
            for d in errors:
                print(d, file=sys.stderr)
            return 1

    lexer = Lexer(source)
    tokens = lexer.tokenize()
    parser = Parser(tokens)
    program = parser.parse()

    interpreter = Interpreter(safe_mode='--sandbox' in flags)
    interpreter.execute(program)
    return 0


# ─── New Project ──────────────────────────────────────────

def _new_project(args):
    """Create a new EPL project with full structure."""
    if not args:
        print(f"{_red('Error:')} No project name specified.")
        print(f"Usage: epl new <project-name>")
        return 1

    name = args[0]

    # Validate project name
    import re
    if not re.match(r'^[a-zA-Z][a-zA-Z0-9_-]*$', name):
        print(f"{_red('Error:')} Invalid project name: {name}")
        print("Use letters, digits, hyphens, underscores. Must start with a letter.")
        return 1

    if os.path.exists(name):
        print(f"{_red('Error:')} Directory '{name}' already exists.")
        return 1

    # Create project structure
    os.makedirs(name)
    os.makedirs(os.path.join(name, 'src'))
    os.makedirs(os.path.join(name, 'tests'))
    os.makedirs(os.path.join(name, 'lib'))

    # epl.toml manifest
    from epl.package_manager import create_manifest, _dump_toml, _manifest_to_toml
    manifest_data = {
        "name": name,
        "version": "1.0.0",
        "description": f"{name} — an EPL project",
        "entry": "src/main.epl",
        "author": "",
        "scripts": {
            "start": "epl run src/main.epl",
            "test": "epl test tests/",
            "build": "epl build src/main.epl"
        },
        "dependencies": {},
    }
    toml_data = _manifest_to_toml(manifest_data)
    with open(os.path.join(name, 'epl.toml'), 'w', encoding='utf-8') as f:
        f.write(_dump_toml(toml_data) + '\\n')

    # Main source file
    with open(os.path.join(name, 'src', 'main.epl'), 'w', encoding='utf-8') as f:
        f.write(f'Note: {name} — Created with EPL v{__version__}\n')
        f.write(f'\n')
        f.write(f'Say "Hello from {name}!"\n')
        f.write(f'Say "Edit src/main.epl to get started."\n')

    # Example test file
    with open(os.path.join(name, 'tests', 'test_main.epl'), 'w', encoding='utf-8') as f:
        f.write(f'Note: Tests for {name}\n\n')
        f.write(f'Assert 1 + 1 == 2\n')
        f.write(f'Assert length("hello") == 5\n')
        f.write(f'Say "All tests passed!"\n')

    # README
    with open(os.path.join(name, 'README.md'), 'w', encoding='utf-8') as f:
        f.write(f'# {name}\n\n')
        f.write(f'An EPL project.\n\n')
        f.write(f'## Getting Started\n\n')
        f.write(f'```bash\n')
        f.write(f'# Run the project\n')
        f.write(f'epl run src/main.epl\n\n')
        f.write(f'# Run tests\n')
        f.write(f'epl test tests/\n\n')
        f.write(f'# Compile to executable\n')
        f.write(f'epl build src/main.epl\n')
        f.write(f'```\n')

    # .gitignore
    with open(os.path.join(name, '.gitignore'), 'w', encoding='utf-8') as f:
        f.write('# EPL\nepl_modules/\n*.exe\n*.o\nbuild/\ndist/\n')
        f.write('# Python\n__pycache__/\n*.pyc\n.venv/\n')
        f.write('# IDE\n.vscode/\n.idea/\n')

    print(f"\n  {_green('Created')} EPL project: {_bold(name)}")
    print(f"\n  {_dim('Project structure:')}")
    print(f"    {name}/")
    print(f"    ├── epl.toml          Project manifest")
    print(f"    ├── README.md         Documentation")
    print(f"    ├── .gitignore        Git ignore rules")
    print(f"    ├── src/")
    print(f"    │   └── main.epl      Entry point")
    print(f"    ├── tests/")
    print(f"    │   └── test_main.epl Test file")
    print(f"    └── lib/              Local libraries")
    print(f"\n  {_dim('Get started:')}")
    print(f"    cd {name}")
    print(f"    epl run src/main.epl")
    print()
    return 0


# ─── Build / Compile ─────────────────────────────────────

def _build(args, flags):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified and no epl.toml/epl.json project was found.")
        return 1

    # Delegate to main.py compile logic
    sys.argv = ['epl', 'compile'] + args
    if '--strict' in flags:
        sys.argv.append('--strict')
    from main import main as main_entry
    main_entry()


def _run_tests(args, flags):
    if not args:
        if os.path.isdir('tests'):
            args = ['tests/']
        else:
            print(f"{_red('Error:')} No test directory found.")
            return 1

    sys.argv = ['epl', 'test'] + args
    from main import main as main_entry
    main_entry()


def _run_repl(flags):
    sys.argv = ['epl']
    if '--strict' in flags:
        sys.argv.append('--strict')
    if '--sandbox' in flags:
        sys.argv.append('--sandbox')
    from main import main as main_entry
    main_entry()


def _pkg_install(args):
    if not args:
        # No args = install all deps from manifest
        sys.argv = ['epl', 'install']
        from main import main as main_entry
        main_entry()
        return
    sys.argv = ['epl', 'install'] + args
    from main import main as main_entry
    main_entry()


def _pkg_uninstall(args):
    if not args:
        print(f"{_red('Error:')} No package specified.")
        return 1
    sys.argv = ['epl', 'uninstall'] + args
    from main import main as main_entry
    main_entry()


def _pkg_list():
    sys.argv = ['epl', 'packages']
    from main import main as main_entry
    main_entry()


def _init_project(args):
    name = args[0] if args else None
    sys.argv = ['epl', 'init']
    if name:
        sys.argv.append(name)
    from main import main as main_entry
    main_entry()


def _delegate(command, args):
    """Delegate a command to main.py for commands not yet ported to cli.py."""
    sys.argv = ['epl', command] + list(args)
    from main import main as main_entry
    main_entry()


def _serve(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified and no epl.toml/epl.json project was found.")
        return 1
    sys.argv = ['epl', 'serve'] + args
    from main import main as main_entry
    main_entry()


def _deploy(args):
    sys.argv = ['epl', 'deploy'] + args
    from main import main as main_entry
    main_entry()


def _format(args):
    sys.argv = ['epl', 'fmt'] + args
    from main import main as main_entry
    main_entry()


def _lint(args):
    sys.argv = ['epl', 'lint'] + args
    from main import main as main_entry
    main_entry()


def _docs(args):
    sys.argv = ['epl', 'docs'] + args
    from main import main as main_entry
    main_entry()


def _debug(args, flags):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    sys.argv = ['epl', 'debug'] + args
    from main import main as main_entry
    main_entry()


def _transpile_js(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    sys.argv = ['epl', 'js'] + args
    from main import main as main_entry
    main_entry()


def _transpile_node(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    sys.argv = ['epl', 'node'] + args
    from main import main as main_entry
    main_entry()


def _transpile_kotlin(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    sys.argv = ['epl', 'kotlin'] + args
    from main import main as main_entry
    main_entry()


def _android(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    sys.argv = ['epl', 'android'] + args
    from main import main as main_entry
    main_entry()


def _show_ir(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    sys.argv = ['epl', 'ir'] + args
    from main import main as main_entry
    main_entry()


def _run_vm(args, flags):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    sys.argv = ['epl', 'vm'] + args
    from main import main as main_entry
    main_entry()


def _start_lsp(args):
    sys.argv = ['epl', 'lsp'] + args
    from main import main as main_entry
    main_entry()


def _ai(args):
    sys.argv = ['epl', 'ai'] + args
    from main import main as main_entry
    main_entry()


def _ai_gen(args):
    sys.argv = ['epl', 'gen'] + args
    from main import main as main_entry
    main_entry()


def _ai_explain(args):
    sys.argv = ['epl', 'explain'] + args
    from main import main as main_entry
    main_entry()


def _package(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    sys.argv = ['epl', 'package'] + args
    from main import main as main_entry
    main_entry()


def _cloud():
    sys.argv = ['epl', 'cloud']
    from main import main as main_entry
    main_entry()


def _train():
    sys.argv = ['epl', 'train']
    from main import main as main_entry
    main_entry()


def _model():
    sys.argv = ['epl', 'model']
    from main import main as main_entry
    main_entry()


# ─── Phase 7 Commands ────────────────────────────────────

def _resolve():
    from epl.resolver import resolve_from_manifest, print_resolution
    result = resolve_from_manifest()
    print_resolution(result)


def _workspace(args):
    from epl.workspace import workspace_cli
    workspace_cli(list(args))


def _ci(args):
    from epl.ci_gen import ci_cli
    ci_cli(list(args))


def _sync_index(args):
    from epl.package_index import PackageIndex
    idx = PackageIndex()
    force = '--force' in args
    if idx.sync_index(force=force):
        print("  Package index synced successfully.")
    else:
        print("  Failed to sync package index.")


def _list_modules():
    """List available EPL standard library modules."""
    import json
    registry_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'stdlib', 'registry.json')
    try:
        with open(registry_path, 'r', encoding='utf-8') as f:
            registry = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        print(f"{_red('Error:')} stdlib registry not found.")
        return 1

    print(f"\n{_bold('EPL Standard Library Modules')}")
    print(_dim('Use: Import "name" to load a module') + "\n")
    for name, info in registry['modules'].items():
        print(f"  {_green(name):30s} {info['description']}")
    count = len(registry['modules'])
    print(f"\n{_dim(f'{count} modules available | EPL v{__version__}')}\n")
    return 0


# ─── Entry Point ──────────────────────────────────────────

def main():
    """CLI entry point for setuptools console_scripts."""
    sys.exit(cli_main())


if __name__ == '__main__':
    main()
