"""Test correct v0.46 API."""
import llvmlite.binding as llvm

# Initialize LLVM targets (required before any target operations)
try:
    llvm.initialize()
    llvm.initialize_native_target()
    llvm.initialize_native_asmprinter()
except Exception:
    try:
        llvm.initialize_all_targets()
        llvm.initialize_all_asmprinters()
    except Exception:
        pass

# Step 1: Get target
print("Step 1: Get target...")
t = llvm.targets.Target.from_default_triple()
print(f"  Target: {t.name}")

# Step 2: Create target machine
print("Step 2: Create target machine...")
tm = t.create_target_machine(opt=2)
print(f"  TargetMachine created")

# Step 3: Parse IR
print("Step 3: Parse IR...")
ir_str = ''
ir_str += 'target triple = "x86_64-pc-windows-msvc"\n'
ir_str += 'target datalayout = ""\n'
ir_str += '\n'
ir_str += 'declare i32 @printf(i8*, ...)\n'
ir_str += '@fmt = private constant [6 x i8] c"%lld\\0a\\00"\n'
ir_str += '\n'
ir_str += 'define i32 @main() {\n'
ir_str += 'entry:\n'
ir_str += '  %fmt_ptr = bitcast [6 x i8]* @fmt to i8*\n'
ir_str += '  call i32 (i8*, ...) @printf(i8* %fmt_ptr, i64 42)\n'
ir_str += '  ret i32 0\n'
ir_str += '}\n'

mod = llvm.parse_assembly(ir_str)
mod.verify()
print("  Parsed and verified")

# Step 4: Emit object code
print("Step 4: Emit object code...")
obj = tm.emit_object(mod)
print(f"  Object code: {len(obj)} bytes")

# Step 5: Write to file
with open("test_out.o", "wb") as f:
    f.write(obj)
print("  Written to test_out.o")

print("\nSUCCESS!")
