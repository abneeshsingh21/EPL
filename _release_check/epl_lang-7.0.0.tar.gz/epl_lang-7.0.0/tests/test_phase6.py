"""
EPL Phase 6 Test Suite — Mobile & Desktop
Tests for: Desktop GUI (6a), Android (6b), Web/WASM (6c)
Target: 300+ tests covering all three targets.
"""

import sys
import os
import shutil
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from epl.lexer import Lexer
from epl.parser import Parser
from epl import ast_nodes as ast

# ─── Test Infrastructure ─────────────────────────────────

passed = 0
failed = 0
total = 0


def _parse(source):
    """Parse EPL source into AST."""
    lexer = Lexer(source)
    tokens = lexer.tokenize()
    parser = Parser(tokens)
    return parser.parse()


def test(name, condition):
    """Assert a condition."""
    global passed, failed, total
    total += 1
    if condition:
        passed += 1
        print(f"  PASS: {name}")
    else:
        failed += 1
        print(f"  FAIL: {name}")


def test_contains(name, text, *substrings):
    """Assert text contains all substrings."""
    global passed, failed, total
    total += 1
    missing = [s for s in substrings if s not in text]
    if not missing:
        passed += 1
        print(f"  PASS: {name}")
    else:
        failed += 1
        print(f"  FAIL: {name}")
        for m in missing:
            print(f"    Missing: {m!r}")


def test_file_exists(name, path):
    """Assert a file exists."""
    global passed, failed, total
    total += 1
    if os.path.exists(path):
        passed += 1
        print(f"  PASS: {name}")
    else:
        failed += 1
        print(f"  FAIL: {name} — file not found: {path}")


def section(title):
    print(f"\n--- {title} ---")


# ─── Cleanup Helper ─────────────────────────────────────

_temp_dirs = []

def make_temp_dir():
    d = tempfile.mkdtemp(prefix='epl_test_')
    _temp_dirs.append(d)
    return d

def cleanup():
    for d in _temp_dirs:
        try:
            shutil.rmtree(d, ignore_errors=True)
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
# 6a — Desktop GUI Tests
# ═══════════════════════════════════════════════════════════

def test_desktop_import():
    section("6a Desktop — Module Import")
    from epl.desktop import (
        DesktopProjectGenerator, DesktopComposeGenerator,
        generate_desktop_project, generate_desktop_kotlin
    )
    test("DesktopProjectGenerator importable", DesktopProjectGenerator is not None)
    test("DesktopComposeGenerator importable", DesktopComposeGenerator is not None)
    test("generate_desktop_project importable", callable(generate_desktop_project))
    test("generate_desktop_kotlin importable", callable(generate_desktop_kotlin))


def test_desktop_generator_init():
    section("6a Desktop — Generator Initialization")
    from epl.desktop import DesktopProjectGenerator, DesktopComposeGenerator

    gen = DesktopProjectGenerator("MyApp", "com.test.app", 1024, 768)
    test("app_name set", gen.app_name == "MyApp")
    test("package set", gen.package == "com.test.app")
    test("width set", gen.width == 1024)
    test("height set", gen.height == 768)
    test("package_path set", gen.package_path == "com/test/app")
    test("version default", gen.version == "1.0.0")

    cg = DesktopComposeGenerator("com.test.app", "Test App", 800, 600)
    test("compose gen package", cg.package == "com.test.app")
    test("compose gen title", cg.app_title == "Test App")
    test("compose gen width", cg.width == 800)
    test("compose gen height", cg.height == 600)


def test_desktop_simple_program():
    section("6a Desktop — Simple Program Codegen")
    from epl.desktop import DesktopComposeGenerator

    program = _parse('Display "Hello Desktop"')
    gen = DesktopComposeGenerator("com.epl.test", "Test App")
    code = gen.generate(program)

    test_contains("has package", code, "package com.epl.test")
    test_contains("has imports", code, "import androidx.compose")
    test_contains("has fun main()", code, "fun main()")
    test_contains("has application block", code, "application {")
    test_contains("has Window composable", code, "Window(")
    test_contains("has MaterialTheme", code, "MaterialTheme")
    test_contains("has AppContent", code, "AppContent()")
    test_contains("has @Composable", code, "@Composable")
    test_contains("has Text", code, "Text(")


def test_desktop_variables():
    section("6a Desktop — Variables in Codegen")
    from epl.desktop import DesktopComposeGenerator

    program = _parse('''
Set x to 42
Set name to "Desktop"
Display x
Display name
''')
    gen = DesktopComposeGenerator()
    code = gen.generate(program)

    test_contains("has Text for x", code, "Text(")
    test("has multiple Text widgets", code.count("Text(") >= 2)


def test_desktop_function():
    section("6a Desktop — Function Codegen")
    from epl.desktop import DesktopComposeGenerator

    program = _parse('''
Function greet takes name
    Display "Hello " + name
End
''')
    gen = DesktopComposeGenerator()
    code = gen.generate(program)

    test_contains("has fun greet", code, "fun greet(")
    test_contains("has println", code, "println(")


def test_desktop_class():
    section("6a Desktop — Class Codegen")
    from epl.desktop import DesktopComposeGenerator

    program = _parse('''
Class Animal
    Set species to "Unknown"
End
''')
    gen = DesktopComposeGenerator()
    code = gen.generate(program)

    test_contains("has open class", code, "open class Animal")


def test_desktop_conditionals():
    section("6a Desktop — Conditionals in Codegen")
    from epl.desktop import DesktopComposeGenerator

    program = _parse('''
Set x to 10
If x > 5 Then
    Display "big"
Otherwise
    Display "small"
End
''')
    gen = DesktopComposeGenerator()
    code = gen.generate(program)

    test_contains("has if block", code, "if (")
    test_contains("has else block", code, "} else {")


def test_desktop_loops():
    section("6a Desktop — Loops in Codegen")
    from epl.desktop import DesktopComposeGenerator

    program = _parse('''
For Each item In [1, 2, 3]
    Display item
End
''')
    gen = DesktopComposeGenerator()
    code = gen.generate(program)

    test_contains("has for loop", code, "for (item in")


def test_desktop_while_loop():
    section("6a Desktop — While Loop Codegen")
    from epl.desktop import DesktopComposeGenerator

    program = _parse('''
Set i to 0
While i < 5
    Display i
    Set i to i + 1
End
''')
    gen = DesktopComposeGenerator()
    code = gen.generate(program)

    test_contains("has while loop", code, "while (")


def test_desktop_try_catch():
    section("6a Desktop — Try/Catch Codegen")
    from epl.desktop import DesktopComposeGenerator

    program = _parse('''
Try
    Display "trying"
Catch e
    Display "caught"
End
''')
    gen = DesktopComposeGenerator()
    code = gen.generate(program)

    test_contains("has try block", code, "try {")
    test_contains("has catch block", code, "catch (")


def test_desktop_gui_widgets():
    section("6a Desktop — GUI Widget Codegen")
    from epl.desktop import DesktopComposeGenerator

    program = _parse('''
Window "My App"
    Label "Welcome!"
    Button "Click Me" called btn1
    TextBox called txtName
    Checkbox "Agree" called chk1
End
''')
    gen = DesktopComposeGenerator()
    code = gen.generate(program)

    test_contains("has Text for label", code, "Text(")
    test_contains("has Button composable", code, "Button(onClick")
    test_contains("has TextField", code, "TextField(")
    test_contains("has Checkbox composable", code, "Checkbox(")
    test_contains("has remember state", code, "remember {")
    test_contains("has mutableStateOf", code, "mutableStateOf")


def test_desktop_runtime():
    section("6a Desktop — Runtime Generation")
    from epl.desktop import DesktopComposeGenerator

    gen = DesktopComposeGenerator("com.test.app")
    runtime = gen.generate_runtime()

    test_contains("has package", runtime, "package com.test.app")
    test_contains("has EPLRuntime object", runtime, "object EPLRuntime")
    test_contains("has print function", runtime, "fun print(")
    test_contains("has input function", runtime, "fun input(")
    test_contains("has toInteger", runtime, "fun toInteger(")
    test_contains("has toDecimal", runtime, "fun toDecimal(")
    test_contains("has toText", runtime, "fun toText(")
    test_contains("has length", runtime, "fun length(")
    test_contains("has uppercase", runtime, "fun uppercase(")
    test_contains("has lowercase", runtime, "fun lowercase(")
    test_contains("has absolute", runtime, "fun absolute(")
    test_contains("has power", runtime, "fun power(")
    test_contains("has squareRoot", runtime, "fun squareRoot(")
    test_contains("has random", runtime, "fun random()")
    test_contains("has readFile", runtime, "fun readFile(")
    test_contains("has writeFile", runtime, "fun writeFile(")
    test_contains("has now", runtime, "fun now()")
    test_contains("has showMessage dialog", runtime, "fun showMessage(")
    test_contains("has showError dialog", runtime, "fun showError(")
    test_contains("has askYesNo dialog", runtime, "fun askYesNo(")
    test_contains("has askText dialog", runtime, "fun askText(")
    test_contains("has openFileDialog", runtime, "fun openFileDialog(")
    test_contains("has saveFileDialog", runtime, "fun saveFileDialog(")
    test_contains("has sleep", runtime, "fun sleep(")
    test_contains("has exit", runtime, "fun exit(")
    test_contains("has env", runtime, "fun env(")
    test_contains("has execute", runtime, "fun execute(")
    test_contains("has toJson", runtime, "fun toJson(")


def test_desktop_project_generation():
    section("6a Desktop — Full Project Generation")
    from epl.desktop import generate_desktop_project

    program = _parse('Display "Hello Desktop"')
    out = make_temp_dir()
    result = generate_desktop_project(program, out, app_name="TestApp",
                                       package="com.test.desktop")

    test("returns output dir", result == out)

    # Check all project files exist
    test_file_exists("build.gradle.kts", f"{out}/build.gradle.kts")
    test_file_exists("settings.gradle.kts", f"{out}/settings.gradle.kts")
    test_file_exists("gradle.properties", f"{out}/gradle.properties")
    test_file_exists("gradlew", f"{out}/gradlew")
    test_file_exists("gradlew.bat", f"{out}/gradlew.bat")
    test_file_exists("gradle-wrapper.properties", f"{out}/gradle/wrapper/gradle-wrapper.properties")
    test_file_exists(".gitignore", f"{out}/.gitignore")
    test_file_exists("README.md", f"{out}/README.md")
    test_file_exists("Main.kt", f"{out}/src/main/kotlin/com/test/desktop/Main.kt")
    test_file_exists("EPLRuntime.kt", f"{out}/src/main/kotlin/com/test/desktop/EPLRuntime.kt")

    # Check build.gradle.kts content
    with open(f"{out}/build.gradle.kts", 'r') as f:
        bg = f.read()
    test_contains("gradle has compose plugin", bg, "org.jetbrains.compose")
    test_contains("gradle has kotlin jvm", bg, 'kotlin("jvm")')
    test_contains("gradle has compose desktop", bg, "compose.desktop")
    test_contains("gradle has mainClass", bg, "mainClass")
    test_contains("gradle has nativeDistributions", bg, "nativeDistributions")
    test_contains("gradle has Msi format", bg, "TargetFormat.Msi")
    test_contains("gradle has Dmg format", bg, "TargetFormat.Dmg")
    test_contains("gradle has Deb format", bg, "TargetFormat.Deb")
    test_contains("gradle has package name", bg, "TestApp")

    # Check Main.kt content
    with open(f"{out}/src/main/kotlin/com/test/desktop/Main.kt", 'r') as f:
        mk = f.read()
    test_contains("main.kt has package", mk, "package com.test.desktop")
    test_contains("main.kt has fun main", mk, "fun main()")
    test_contains("main.kt has Window", mk, "Window(")

    # Check README
    with open(f"{out}/README.md", 'r') as f:
        readme = f.read()
    test_contains("readme has app name", readme, "TestApp")
    test_contains("readme has gradlew run", readme, "./gradlew run")


def test_desktop_build_gradle_details():
    section("6a Desktop — Build Gradle Details")
    from epl.desktop import DesktopProjectGenerator

    gen = DesktopProjectGenerator("MyDesktop", "com.my.app")
    bg = gen._build_gradle()

    test_contains("has compose import", bg, "import org.jetbrains.compose")
    test_contains("has material3", bg, "compose.material3")
    test_contains("has coroutines", bg, "kotlinx-coroutines-core")
    test_contains("has mavenCentral", bg, "mavenCentral()")
    test_contains("has jetbrains repo", bg, "maven.pkg.jetbrains.space")
    test_contains("has windows config", bg, "windows {")
    test_contains("has macOS config", bg, "macOS {")
    test_contains("has linux config", bg, "linux {")
    test_contains("has Rpm format", bg, "TargetFormat.Rpm")
    test_contains("has JUnit", bg, "useJUnitPlatform")


def test_desktop_settings_gradle():
    section("6a Desktop — Settings Gradle")
    from epl.desktop import DesktopProjectGenerator

    gen = DesktopProjectGenerator("MyApp")
    sg = gen._settings_gradle()

    test_contains("has pluginManagement", sg, "pluginManagement")
    test_contains("has compose dev repo", sg, "maven.pkg.jetbrains.space")
    test_contains("has root project name", sg, "MyApp")


def test_desktop_expression_codegen():
    section("6a Desktop — Expression Codegen")
    from epl.desktop import DesktopComposeGenerator

    gen = DesktopComposeGenerator()

    # Literal expressions
    lit_int = ast.Literal(42)
    test("int literal", gen._expr(lit_int) == "42")

    lit_str = ast.Literal("hello")
    test("string literal", gen._expr(lit_str) == '"hello"')

    lit_bool_t = ast.Literal(True)
    test("bool true", gen._expr(lit_bool_t) == "true")

    lit_bool_f = ast.Literal(False)
    test("bool false", gen._expr(lit_bool_f) == "false")

    lit_none = ast.Literal(None)
    test("null literal", gen._expr(lit_none) == "null")

    # Identifier
    ident = ast.Identifier("myVar")
    test("identifier", gen._expr(ident) == "myVar")

    # BinaryOp
    binop = ast.BinaryOp(ast.Literal(1), '+', ast.Literal(2))
    result = gen._expr(binop)
    test("binary add", '1' in result and '2' in result and '+' in result)

    # UnaryOp  
    unary = ast.UnaryOp('not', ast.Literal(True))
    result = gen._expr(unary)
    test("unary not", '!' in result)

    # ListLiteral
    lst = ast.ListLiteral([ast.Literal(1), ast.Literal(2), ast.Literal(3)])
    result = gen._expr(lst)
    test("list literal", 'mutableListOf' in result)

    # DictLiteral
    dct = ast.DictLiteral([(ast.Literal("a"), ast.Literal(1))])
    result = gen._expr(dct)
    test("dict literal", 'mutableMapOf' in result)


def test_desktop_widget_types():
    section("6a Desktop — All Widget Types")
    from epl.desktop import DesktopComposeGenerator

    widget_tests = [
        ('button', {'text': 'Click', 'action': None}),
        ('label', {'text': 'Info'}),
        ('input', {'properties': {'placeholder': 'Enter'}}),
        ('textarea', {'properties': {'placeholder': 'Write'}}),
        ('checkbox', {'text': 'Enable'}),
        ('slider', {'properties': {'max': 200}}),
        ('progress', {}),
        ('dropdown', {'properties': {'options': ['A', 'B']}}),
        ('canvas', {'properties': {'width': 500, 'height': 400}}),
        ('image', {'text': 'logo.png'}),
        ('separator', {}),
        ('listbox', {}),
    ]

    for wtype, props in widget_tests:
        gen = DesktopComposeGenerator()
        gen.output = []
        gen.indent = 0
        gen.widget_counter += 1
        widget = {
            'id': f'test_{wtype}',
            'type': wtype,
            'text': props.get('text'),
            'properties': props.get('properties', {}),
            'action': props.get('action'),
        }
        gen._emit_compose_widget(widget)
        code = '\n'.join(gen.output)
        test(f"widget {wtype} emits code", len(code.strip()) > 0)


# ═══════════════════════════════════════════════════════════
# 6b — Android Tests
# ═══════════════════════════════════════════════════════════

def test_android_import():
    section("6b Android — Module Import")
    from epl.kotlin_gen import (
        KotlinGenerator, AndroidProjectGenerator,
        transpile_to_kotlin, generate_android_project
    )
    test("KotlinGenerator importable", KotlinGenerator is not None)
    test("AndroidProjectGenerator importable", AndroidProjectGenerator is not None)
    test("transpile_to_kotlin importable", callable(transpile_to_kotlin))
    test("generate_android_project importable", callable(generate_android_project))


def test_android_kotlin_transpile():
    section("6b Android — Kotlin Transpilation")
    from epl.kotlin_gen import transpile_to_kotlin

    program = _parse('Display "Hello Android"')
    kt = transpile_to_kotlin(program, package="com.test.android")

    test_contains("has package", kt, "package com.test.android")
    test_contains("has fun main", kt, "fun main()")
    test_contains("has println", kt, "println(")


def test_android_variables():
    section("6b Android — Variable Transpilation")
    from epl.kotlin_gen import KotlinGenerator

    program = _parse('''
Set x to 42
Set name to "test"
Set pi to 3.14
Set flag to True
''')
    gen = KotlinGenerator("com.test")
    code = gen.generate(program)

    test_contains("has x assignment", code, "x = ")
    test_contains("has name assignment", code, "name = ")
    test_contains("has pi assignment", code, "pi = ")


def test_android_functions():
    section("6b Android — Function Transpilation")
    from epl.kotlin_gen import KotlinGenerator

    program = _parse('''
Function add takes a and b
    Return a + b
End

Function greet takes name
    Display "Hello " + name
End
''')
    gen = KotlinGenerator("com.test")
    code = gen.generate(program)

    test_contains("has fun add", code, "fun add(")
    test_contains("has fun greet", code, "fun greet(")
    test_contains("has return", code, "return")


def test_android_classes():
    section("6b Android — Class Transpilation")
    from epl.kotlin_gen import KotlinGenerator

    program = _parse('''
Class Vehicle
    Set speed to 0
    Function accelerate
        Set speed to speed + 10
    End
End
''')
    gen = KotlinGenerator("com.test")
    code = gen.generate(program)

    test_contains("has class Vehicle", code, "class Vehicle")
    test_contains("has speed property", code, "speed")


def test_android_conditionals():
    section("6b Android — Conditional Transpilation")
    from epl.kotlin_gen import KotlinGenerator

    program = _parse('''
Set age to 20
If age >= 18 Then
    Display "adult"
Otherwise
    Display "minor"
End
''')
    gen = KotlinGenerator("com.test")
    code = gen.generate(program)

    test_contains("has if", code, "if (")
    test_contains("has else", code, "else")


def test_android_loops():
    section("6b Android — Loop Transpilation")
    from epl.kotlin_gen import KotlinGenerator

    program = _parse('''
For Each item In [1, 2, 3]
    Display item
End

Set i to 0
While i < 10
    Set i to i + 1
End
''')
    gen = KotlinGenerator("com.test")
    code = gen.generate(program)

    test_contains("has for loop", code, "for (")
    test_contains("has while loop", code, "while (")


def test_android_collections():
    section("6b Android — Collection Transpilation")
    from epl.kotlin_gen import KotlinGenerator

    program = _parse('''
Set myList to [1, 2, 3]
Set myDict to Map with key = "value"
''')
    gen = KotlinGenerator("com.test")
    code = gen.generate(program)

    test_contains("has list creation", code, "mutableListOf(")
    test_contains("has map creation", code, "mutableMapOf(")


def test_android_try_catch():
    section("6b Android — Try/Catch Transpilation")
    from epl.kotlin_gen import KotlinGenerator

    program = _parse('''
Try
    Display "test"
Catch e
    Display "error"
End
''')
    gen = KotlinGenerator("com.test")
    code = gen.generate(program)

    test_contains("has try", code, "try {")
    test_contains("has catch", code, "catch (")


def test_android_project_generation():
    section("6b Android — Full Project Generation")
    from epl.kotlin_gen import generate_android_project

    program = _parse('Display "Hello Android"')
    out = make_temp_dir()
    result = generate_android_project(program, out, app_name="TestAndroid",
                                       package="com.test.android")

    test("returns output dir", result == out)

    # Core files
    test_file_exists("AndroidManifest.xml", f"{out}/app/src/main/AndroidManifest.xml")
    test_file_exists("MainActivity.kt", f"{out}/app/src/main/java/com/test/android/MainActivity.kt")
    test_file_exists("EPLRuntime.kt", f"{out}/app/src/main/java/com/test/android/EPLRuntime.kt")
    test_file_exists("EPLApplication.kt", f"{out}/app/src/main/java/com/test/android/EPLApplication.kt")
    test_file_exists("app build.gradle.kts", f"{out}/app/build.gradle.kts")
    test_file_exists("root build.gradle.kts", f"{out}/build.gradle.kts")
    test_file_exists("settings.gradle.kts", f"{out}/settings.gradle.kts")
    test_file_exists("gradle.properties", f"{out}/gradle.properties")
    test_file_exists("gradlew", f"{out}/gradlew")
    test_file_exists("proguard-rules.pro", f"{out}/app/proguard-rules.pro")

    # Data layer
    test_file_exists("Repository.kt", f"{out}/app/src/main/java/com/test/android/data/Repository.kt")
    test_file_exists("EPLEntity.kt", f"{out}/app/src/main/java/com/test/android/data/model/EPLEntity.kt")
    test_file_exists("EPLDao.kt", f"{out}/app/src/main/java/com/test/android/data/local/EPLDao.kt")
    test_file_exists("EPLDatabase.kt", f"{out}/app/src/main/java/com/test/android/data/local/EPLDatabase.kt")
    test_file_exists("ApiService.kt", f"{out}/app/src/main/java/com/test/android/data/remote/ApiService.kt")
    test_file_exists("RetrofitClient.kt", f"{out}/app/src/main/java/com/test/android/data/remote/RetrofitClient.kt")

    # UI layer
    test_file_exists("MainViewModel.kt", f"{out}/app/src/main/java/com/test/android/ui/MainViewModel.kt")
    test_file_exists("ItemAdapter.kt", f"{out}/app/src/main/java/com/test/android/ui/ItemAdapter.kt")

    # Resources
    test_file_exists("activity_main.xml", f"{out}/app/src/main/res/layout/activity_main.xml")
    test_file_exists("strings.xml", f"{out}/app/src/main/res/values/strings.xml")
    test_file_exists("themes.xml", f"{out}/app/src/main/res/values/themes.xml")
    test_file_exists("colors.xml", f"{out}/app/src/main/res/values/colors.xml")
    test_file_exists("nav_graph.xml", f"{out}/app/src/main/res/navigation/nav_graph.xml")
    test_file_exists("main_menu.xml", f"{out}/app/src/main/res/menu/main_menu.xml")

    # Tests
    test_file_exists("unit test", f"{out}/app/src/test/java/com/test/android/EPLRuntimeTest.kt")
    test_file_exists("instrumented test", f"{out}/app/src/androidTest/java/com/test/android/MainActivityTest.kt")

    # Check manifest content
    with open(f"{out}/app/src/main/AndroidManifest.xml", 'r') as f:
        manifest = f.read()
    test_contains("manifest has package", manifest, "com.test.android")
    test_contains("manifest has INTERNET permission", manifest, "android.permission.INTERNET")
    test_contains("manifest has MainActivity", manifest, ".MainActivity")


def test_android_manifest_details():
    section("6b Android — Manifest Details")
    from epl.kotlin_gen import AndroidProjectGenerator

    gen = AndroidProjectGenerator("TestApp", "com.epl.test")
    manifest = gen._manifest()

    test_contains("has package", manifest, 'package="com.epl.test"')
    test_contains("has INTERNET", manifest, "android.permission.INTERNET")
    test_contains("has ACCESS_NETWORK_STATE", manifest, "android.permission.ACCESS_NETWORK_STATE")
    test_contains("has icon", manifest, "@mipmap/ic_launcher")
    test_contains("has theme", manifest, "@style/Theme.EPLApp")
    test_contains("has application name", manifest, ".EPLApplication")
    test_contains("has exported=true", manifest, 'android:exported="true"')


def test_android_strings_xml():
    section("6b Android — Strings XML")
    from epl.kotlin_gen import AndroidProjectGenerator

    gen = AndroidProjectGenerator("MyAndroidApp", "com.epl.app")
    strings = gen._strings()

    test_contains("has app_name", strings, "app_name")
    test("is valid XML", strings.strip().startswith('<?xml') or strings.strip().startswith('<resources'))


def test_android_themes():
    section("6b Android — Themes")
    from epl.kotlin_gen import AndroidProjectGenerator

    gen = AndroidProjectGenerator("TestApp", "com.epl.app")
    themes = gen._themes()
    themes_night = gen._themes_night()

    test_contains("has style tag", themes, "<style")
    test_contains("has Theme.EPLApp", themes, "Theme.EPLApp")
    test_contains("night has style", themes_night, "<style")


def test_android_colors():
    section("6b Android — Colors")
    from epl.kotlin_gen import AndroidProjectGenerator

    gen = AndroidProjectGenerator()
    colors = gen._colors()

    test_contains("has color tag", colors, "<color")
    test("has multiple colors", colors.count("<color") >= 3)


def test_android_gradle():
    section("6b Android — Gradle Files")
    from epl.kotlin_gen import AndroidProjectGenerator

    gen = AndroidProjectGenerator("TestApp", "com.epl.app")
    app_gradle = gen._app_gradle()
    root_gradle = gen._root_gradle()
    settings = gen._settings()

    test_contains("app gradle has android block", app_gradle, "android {")
    test_contains("app gradle has compileSdk", app_gradle, "compileSdk")
    test_contains("app gradle has defaultConfig", app_gradle, "defaultConfig")
    test_contains("app gradle has dependencies", app_gradle, "dependencies")
    test_contains("app gradle has applicationId", app_gradle, "com.epl.app")

    test_contains("root gradle has plugins", root_gradle, "plugins")

    test_contains("settings has app", settings, ":app")


def test_android_proguard():
    section("6b Android — ProGuard")
    from epl.kotlin_gen import AndroidProjectGenerator

    gen = AndroidProjectGenerator()
    rules = gen._proguard_rules()

    test("proguard not empty", len(rules.strip()) > 0)


def test_android_symbol_table():
    section("6b Android — Symbol Table")
    from epl.kotlin_gen import SymbolTable

    st = SymbolTable()
    st.define("x", "Int")
    test("lookup defined var", st.lookup("x") == "Int")
    test("lookup undefined var", st.lookup("y") is None)

    st.define_function("add", [("a", "Int"), ("b", "Int")], "Int")
    fn = st.lookup_function("add")
    test("lookup function", fn is not None)
    test("function return type", fn['return'] == "Int")

    st.define_class("Foo", {'properties': {}, 'methods': {}, 'parent': None})
    cls = st.lookup_class("Foo")
    test("lookup class", cls is not None)

    # Child scope
    child = st.child()
    child.define("y", "String")
    test("child defines own", child.lookup("y") == "String")
    test("child sees parent", child.lookup("x") == "Int")
    test("parent doesn't see child", st.lookup("y") is None)


def test_android_gui_activity():
    section("6b Android — GUI Activity Generation")
    from epl.kotlin_gen import KotlinGenerator

    program = _parse('''
Window "My App"
    Label "Welcome"
    Button "Go" called btnGo
End
''')
    gen = KotlinGenerator("com.test")
    activity = gen.generate_android_activity(program)

    test_contains("has package", activity, "package com.test")
    test_contains("has AppCompatActivity", activity, "AppCompatActivity")
    test_contains("has onCreate", activity, "onCreate")
    test_contains("has setContentView", activity, "setContentView")


def test_android_compose_activity():
    section("6b Android — Compose Activity Generation")
    from epl.kotlin_gen import KotlinGenerator

    program = _parse('''
Window "Compose App"
    Button "Hello" called btn1
    Label "World"
End
''')
    gen = KotlinGenerator("com.test")
    compose = gen.generate_compose_activity(program)

    test_contains("has package", compose, "package com.test")
    test_contains("has ComponentActivity", compose, "ComponentActivity")
    test_contains("has setContent", compose, "setContent")
    test_contains("has @Composable", compose, "@Composable")


# ═══════════════════════════════════════════════════════════
# 6c — Web / WASM Tests
# ═══════════════════════════════════════════════════════════

def test_web_import():
    section("6c Web — Module Import")
    from epl.wasm_web import (
        WebProjectGenerator, WebCodeGenerator,
        generate_web_project, transpile_to_web_js, generate_wasm_glue
    )
    test("WebProjectGenerator importable", WebProjectGenerator is not None)
    test("WebCodeGenerator importable", WebCodeGenerator is not None)
    test("generate_web_project importable", callable(generate_web_project))
    test("transpile_to_web_js importable", callable(transpile_to_web_js))
    test("generate_wasm_glue importable", callable(generate_wasm_glue))


def test_web_js_transpile():
    section("6c Web — JS Transpilation")
    from epl.wasm_web import transpile_to_web_js

    program = _parse('Display "Hello Web"')
    js = transpile_to_web_js(program, app_title="Test")

    test_contains("has strict mode", js, "'use strict'")
    test_contains("has EPL runtime object", js, "const EPL = {")
    test_contains("has EPL.print call", js, "EPL.print(")
    test_contains("has DOMContentLoaded", js, "DOMContentLoaded")


def test_web_js_variables():
    section("6c Web — JS Variable Transpilation")
    from epl.wasm_web import WebCodeGenerator

    program = _parse('''
Set x to 42
Set name to "web"
Constant PI = 3.14
''')
    gen = WebCodeGenerator()
    js = gen.transpile_js(program)

    test_contains("has x assignment", js, "x = 42")
    test_contains("has name assignment", js, 'name = "web"')
    test_contains("has const PI", js, "const PI =")


def test_web_js_functions():
    section("6c Web — JS Function Transpilation")
    from epl.wasm_web import WebCodeGenerator

    program = _parse('''
Function add takes a and b
    Return a + b
End

Function greet takes name
    Display "Hello " + name
End
''')
    gen = WebCodeGenerator()
    js = gen.transpile_js(program)

    test_contains("has function add", js, "function add(")
    test_contains("has function greet", js, "function greet(")
    test_contains("has return", js, "return")
    test_contains("has EPL.print", js, "EPL.print(")


def test_web_js_conditionals():
    section("6c Web — JS Conditional Transpilation")
    from epl.wasm_web import WebCodeGenerator

    program = _parse('''
Set x to 10
If x > 5 Then
    Display "big"
Otherwise
    Display "small"
End
''')
    gen = WebCodeGenerator()
    js = gen.transpile_js(program)

    test_contains("has if block", js, "if (")
    test_contains("has else block", js, "} else {")


def test_web_js_loops():
    section("6c Web — JS Loop Transpilation")
    from epl.wasm_web import WebCodeGenerator

    program = _parse('''
For Each item In [1, 2, 3]
    Display item
End

Set i to 0
While i < 10
    Set i to i + 1
End
''')
    gen = WebCodeGenerator()
    js = gen.transpile_js(program)

    test_contains("has for...of", js, "for (const item of")
    test_contains("has while", js, "while (")


def test_web_js_classes():
    section("6c Web — JS Class Transpilation")
    from epl.wasm_web import WebCodeGenerator

    program = _parse('''
Class Shape
    Set sides to 0
End
''')
    gen = WebCodeGenerator()
    js = gen.transpile_js(program)

    test_contains("has class Shape", js, "class Shape")


def test_web_js_try_catch():
    section("6c Web — JS Try/Catch Transpilation")
    from epl.wasm_web import WebCodeGenerator

    program = _parse('''
Try
    Display "testing"
Catch err
    Display "caught"
End
''')
    gen = WebCodeGenerator()
    js = gen.transpile_js(program)

    test_contains("has try", js, "try {")
    test_contains("has catch", js, "catch (err)")


def test_web_js_collections():
    section("6c Web — JS Collection Transpilation")
    from epl.wasm_web import WebCodeGenerator

    program = _parse('''
Set myList to [1, 2, 3]
Set myDict to Map with a = 1 and b = 2
''')
    gen = WebCodeGenerator()
    js = gen.transpile_js(program)

    test_contains("has array literal", js, "[1, 2, 3]")
    test_contains("has object literal", js, "{")


def test_web_js_builtins():
    section("6c Web — JS Builtin Mapping")
    from epl.wasm_web import WebCodeGenerator

    # Test each builtin maps to EPL.xxx
    builtins_to_test = [
        ('Display length("hello")', 'EPL.length('),
        ('Display toInteger("42")', 'EPL.toInteger('),
        ('Display uppercase("hi")', 'EPL.uppercase('),
        ('Display random()', 'EPL.random('),
        ('Display floor(3.7)', 'EPL.floor('),
        ('Display absolute(-5)', 'EPL.absolute('),
    ]

    for source, expected in builtins_to_test:
        gen = WebCodeGenerator()
        js = gen.transpile_js(_parse(source))
        test(f"builtin {expected.split('(')[0]}", expected in js)


def test_web_js_runtime_functions():
    section("6c Web — JS Runtime Object")
    from epl.wasm_web import WebCodeGenerator

    gen = WebCodeGenerator()
    program = _parse('Display "hi"')
    js = gen.transpile_js(program)

    runtime_funcs = [
        'print', 'input', 'toInteger', 'toDecimal', 'toText',
        'length', 'uppercase', 'lowercase', 'trim', 'contains',
        'replace', 'split', 'substring', 'indexOf', 'startsWith',
        'endsWith', 'random', 'randomInt', 'absolute', 'power',
        'squareRoot', 'floor', 'ceil', 'round', 'sin', 'cos', 'tan',
        'now', 'timestamp', 'toJson', 'fromJson', 'keys', 'values',
        'hasKey', 'append', 'join', 'sorted', 'reversed',
    ]
    for fn in runtime_funcs:
        test(f"runtime has {fn}", fn in js)


def test_web_html_generation():
    section("6c Web — HTML Generation")
    from epl.wasm_web import WebCodeGenerator

    program = _parse('Display "Hello"')
    gen = WebCodeGenerator("My Web App")
    html = gen.generate_html(program, mode='js')

    test_contains("has DOCTYPE", html, "<!DOCTYPE html>")
    test_contains("has html lang", html, '<html lang="en">')
    test_contains("has charset", html, "UTF-8")
    test_contains("has viewport", html, "viewport")
    test_contains("has title", html, "My Web App")
    test_contains("has stylesheet link", html, "style.css")
    test_contains("has script tag", html, "app.js")
    test_contains("has manifest link", html, "manifest.json")
    test_contains("has header", html, "<header>")
    test_contains("has main#app", html, 'id="app"')
    test_contains("has footer", html, "<footer>")


def test_web_html_widgets():
    section("6c Web — HTML Widget Generation")
    from epl.wasm_web import WebCodeGenerator

    program = _parse('''
Window "Widget App"
    Label "Welcome"
    Button "Click" called btn1
    TextBox called txt1
    Checkbox "Agree" called chk1
    Slider called sld1
End
''')
    gen = WebCodeGenerator("Widget App")
    html = gen.generate_html(program, mode='js')

    test_contains("has button element", html, '<button id="btn1"')
    test_contains("has span for label", html, "epl-label")
    test_contains("has input element", html, '<input id="txt1"')
    test_contains("has checkbox", html, 'type="checkbox"')
    test_contains("has slider", html, 'type="range"')


def test_web_css_generation():
    section("6c Web — CSS Generation")
    from epl.wasm_web import WebCodeGenerator

    gen = WebCodeGenerator()
    css = gen.generate_css()

    test_contains("has CSS variables", css, ":root {")
    test_contains("has --primary", css, "--primary:")
    test_contains("has body style", css, "body {")
    test_contains("has header style", css, "header {")
    test_contains("has .epl-btn", css, ".epl-btn")
    test_contains("has .epl-input", css, ".epl-input")
    test_contains("has .epl-textarea", css, ".epl-textarea")
    test_contains("has .epl-checkbox", css, ".epl-checkbox")
    test_contains("has .epl-slider", css, ".epl-slider")
    test_contains("has .epl-select", css, ".epl-select")
    test_contains("has .epl-canvas", css, ".epl-canvas")
    test_contains("has .epl-listbox", css, ".epl-listbox")
    test_contains("has responsive media query", css, "@media")
    test("css is substantial", len(css) > 500)


def test_web_wasm_loader():
    section("6c Web — WASM Loader")
    from epl.wasm_web import WebCodeGenerator

    gen = WebCodeGenerator()
    loader = gen.generate_wasm_loader()

    test_contains("has EPLWasm object", loader, "const EPLWasm =")
    test_contains("has init function", loader, "async init(")
    test_contains("has WebAssembly.instantiate", loader, "WebAssembly.instantiate")
    test_contains("has WASI polyfill", loader, "wasi_snapshot_preview1")
    test_contains("has epl_print_str import", loader, "epl_print_str")
    test_contains("has epl_print_int import", loader, "epl_print_int")
    test_contains("has memory access", loader, "EPLWasm.memory")
    test_contains("has readString", loader, "readString(")
    test_contains("has writeString", loader, "writeString(")
    test_contains("has call function", loader, "call(name")
    test_contains("has auto-init", loader, "DOMContentLoaded")
    test_contains("has export default", loader, "export default EPLWasm")


def test_web_wasm_runtime():
    section("6c Web — WASM Runtime")
    from epl.wasm_web import WebCodeGenerator

    gen = WebCodeGenerator()
    runtime = gen.generate_wasm_runtime()

    test_contains("has EPLRuntime", runtime, "const EPLRuntime =")
    test_contains("has createElement", runtime, "createElement(")
    test_contains("has getElementById", runtime, "getElementById(")
    test_contains("has setText", runtime, "setText(")
    test_contains("has getValue", runtime, "getValue(")
    test_contains("has addClass", runtime, "addClass(")
    test_contains("has canvas getCanvas", runtime, "getCanvas(")
    test_contains("has drawRect", runtime, "drawRect(")
    test_contains("has drawCircle", runtime, "drawCircle(")
    test_contains("has drawText", runtime, "drawText(")
    test_contains("has httpGet", runtime, "httpGet(")
    test_contains("has httpPost", runtime, "httpPost(")
    test_contains("has local storage store", runtime, "store(key")
    test_contains("has local storage load", runtime, "load(key")
    test_contains("has notify", runtime, "notify(")
    test_contains("has copyToClipboard", runtime, "copyToClipboard(")
    test_contains("has animate", runtime, "animate(")
    test_contains("exports to window", runtime, "window.EPLRuntime")


def test_web_wasm_glue():
    section("6c Web — WASM Glue Convenience")
    from epl.wasm_web import generate_wasm_glue

    glue = generate_wasm_glue("Test App")
    test("returns dict", isinstance(glue, dict))
    test("has loader.js key", 'loader.js' in glue)
    test("has runtime.js key", 'runtime.js' in glue)
    test("loader has content", len(glue['loader.js']) > 100)
    test("runtime has content", len(glue['runtime.js']) > 100)


def test_web_js_project_generation():
    section("6c Web — JS Project Generation")
    from epl.wasm_web import generate_web_project

    program = _parse('Display "Hello Web"')
    out = make_temp_dir()
    result = generate_web_project(program, out, app_name="TestWeb", mode="js")

    test("returns output dir", result == out)
    test_file_exists("index.html", f"{out}/public/index.html")
    test_file_exists("app.js", f"{out}/src/js/app.js")
    test_file_exists("style.css", f"{out}/src/css/style.css")
    test_file_exists("package.json", f"{out}/package.json")
    test_file_exists("manifest.json", f"{out}/public/manifest.json")
    test_file_exists("sw.js (service worker)", f"{out}/public/sw.js")
    test_file_exists("README.md", f"{out}/README.md")
    test_file_exists(".gitignore", f"{out}/.gitignore")

    # Check index.html
    with open(f"{out}/public/index.html", 'r') as f:
        html = f.read()
    test_contains("html has title", html, "TestWeb")
    test_contains("html has app.js", html, "app.js")

    # Check app.js
    with open(f"{out}/src/js/app.js", 'r') as f:
        js = f.read()
    test_contains("js has EPL runtime", js, "const EPL =")

    # Check package.json
    with open(f"{out}/package.json", 'r') as f:
        pkg = f.read()
    test_contains("package.json has name", pkg, "testweb")

    # Check service worker
    with open(f"{out}/public/sw.js", 'r') as f:
        sw = f.read()
    test_contains("sw has cache", sw, "CACHE_NAME")
    test_contains("sw has install event", sw, "install")
    test_contains("sw has fetch event", sw, "fetch")


def test_web_wasm_project_generation():
    section("6c Web — WASM Project Generation")
    from epl.wasm_web import generate_web_project

    program = _parse('Display "Hello WASM"')
    out = make_temp_dir()
    result = generate_web_project(program, out, app_name="TestWasm", mode="wasm")

    test("returns output dir", result == out)
    test_file_exists("index.html", f"{out}/public/index.html")
    test_file_exists("loader.js", f"{out}/src/loader.js")
    test_file_exists("runtime.js", f"{out}/src/runtime.js")
    test_file_exists("style.css", f"{out}/src/style.css")
    test_file_exists("package.json", f"{out}/package.json")
    test_file_exists("build.sh", f"{out}/build.sh")
    test_file_exists("README.md", f"{out}/README.md")

    with open(f"{out}/public/index.html", 'r') as f:
        html = f.read()
    test_contains("wasm html has loader script", html, "loader.js")


def test_web_kotlin_js_project_generation():
    section("6c Web — Kotlin/JS Project Generation")
    from epl.wasm_web import generate_web_project

    program = _parse('Display "Hello Kotlin/JS"')
    out = make_temp_dir()
    result = generate_web_project(program, out, app_name="TestKotlinJS", mode="kotlin_js")

    test("returns output dir", result == out)
    pkg_path = "com/epl/web"
    test_file_exists("Main.kt", f"{out}/src/main/kotlin/{pkg_path}/Main.kt")
    test_file_exists("index.html", f"{out}/src/main/resources/index.html")
    test_file_exists("style.css", f"{out}/src/main/resources/style.css")
    test_file_exists("build.gradle.kts", f"{out}/build.gradle.kts")
    test_file_exists("settings.gradle.kts", f"{out}/settings.gradle.kts")
    test_file_exists("gradle.properties", f"{out}/gradle.properties")

    with open(f"{out}/build.gradle.kts", 'r') as f:
        bg = f.read()
    test_contains("kt/js gradle has kotlin js", bg, 'kotlin("js")')
    test_contains("kt/js gradle has browser", bg, "browser {")
    test_contains("kt/js gradle has kotlinx-html", bg, "kotlinx-html-js")

    with open(f"{out}/src/main/kotlin/{pkg_path}/Main.kt", 'r') as f:
        kt = f.read()
    test_contains("kt/js has package", kt, "package com.epl.web")
    test_contains("kt/js has document import", kt, "import kotlinx.browser.document")
    test_contains("kt/js has fun main()", kt, "fun main()")


def test_web_kotlin_js_transpile():
    section("6c Web — Kotlin/JS Transpilation")
    from epl.wasm_web import WebCodeGenerator

    program = _parse('''
Set x to 42
Display "Hello Kotlin/JS"
''')
    gen = WebCodeGenerator("Test")
    kt = gen.transpile_kotlin_js(program, 'com.test.web')

    test_contains("has package", kt, "package com.test.web")
    test_contains("has import document", kt, "import kotlinx.browser.document")
    test_contains("has fun main()", kt, "fun main()")
    test_contains("has console.log", kt, "console.log(")
    test_contains("has x assignment", kt, "x = 42")


def test_web_html_modes():
    section("6c Web — HTML Generation Modes")
    from epl.wasm_web import WebCodeGenerator

    program = _parse('Display "Test"')

    # JS mode
    gen1 = WebCodeGenerator("Test")
    html_js = gen1.generate_html(program, mode='js')
    test_contains("js mode has app.js", html_js, "app.js")

    # WASM mode
    gen2 = WebCodeGenerator("Test")
    html_wasm = gen2.generate_html(program, mode='wasm')
    test_contains("wasm mode has loader.js", html_wasm, "loader.js")

    # Kotlin/JS mode
    gen3 = WebCodeGenerator("Test")
    html_kt = gen3.generate_html(program, mode='kotlin_js')
    test("kotlin_js mode produces html", len(html_kt) > 100)


def test_web_pwa_support():
    section("6c Web — PWA Support")
    from epl.wasm_web import WebProjectGenerator

    gen = WebProjectGenerator("PWAApp")
    manifest = gen._pwa_manifest()

    test_contains("manifest has name", manifest, "PWAApp")
    test_contains("manifest has display", manifest, "standalone")
    test_contains("manifest has theme_color", manifest, "theme_color")
    test_contains("manifest has start_url", manifest, "start_url")

    sw = gen._service_worker()
    test_contains("sw has CACHE_NAME", sw, "CACHE_NAME")
    test_contains("sw has install handler", sw, "install")
    test_contains("sw has fetch handler", sw, "fetch")
    test_contains("sw has caches", sw, "caches")


# ═══════════════════════════════════════════════════════════
# Integration Tests
# ═══════════════════════════════════════════════════════════

def test_integration_all_targets():
    section("Integration — All Targets from Same Source")

    source = '''
Set greeting to "Hello from EPL"
Display greeting

Function double takes n
    Return n * 2
End

Display double(21)
'''
    program = _parse(source)

    from epl.desktop import generate_desktop_kotlin
    from epl.wasm_web import transpile_to_web_js
    from epl.kotlin_gen import transpile_to_kotlin

    desktop_kt = generate_desktop_kotlin(program)
    web_js = transpile_to_web_js(program)
    android_kt = transpile_to_kotlin(program)

    test("desktop generates code", len(desktop_kt) > 100)
    test("web generates code", len(web_js) > 100)
    test("android generates code", len(android_kt) > 50)

    test_contains("desktop has greeting", desktop_kt, "greeting")
    test_contains("web has greeting", web_js, "greeting")
    test_contains("android has greeting", android_kt, "greeting")


def test_integration_gui_all_targets():
    section("Integration — GUI Across Targets")

    source = '''
Window "Test App"
    Label "Welcome"
    Button "OK" called btnOK
    TextBox called txtInput
End
'''
    program = _parse(source)

    from epl.desktop import DesktopComposeGenerator
    from epl.wasm_web import WebCodeGenerator

    dg = DesktopComposeGenerator()
    dk = dg.generate(program)
    test_contains("desktop has Button", dk, "Button(")
    test_contains("desktop has TextField", dk, "TextField(")

    wg = WebCodeGenerator()
    wh = wg.generate_html(program, mode='js')
    test_contains("web has button HTML", wh, "<button")
    test_contains("web has input HTML", wh, "<input")


def test_integration_complex_program():
    section("Integration — Complex Program")

    source = '''
Constant VERSION = "1.0"
Set items to ["apple", "banana", "cherry"]

Function findItem takes collection and target
    For Each item In collection
        If item == target Then
            Return True
        End
    End
    Return False
End

Set found to findItem(items, "banana")
If found Then
    Display "Found banana!"
Otherwise
    Display "Not found"
End

Try
    Display "Processing..."
Catch e
    Display "Error: " + e
End
'''
    program = _parse(source)

    from epl.desktop import generate_desktop_kotlin
    from epl.wasm_web import transpile_to_web_js

    dk = generate_desktop_kotlin(program)
    wj = transpile_to_web_js(program)

    test("desktop complex output", len(dk) > 200)
    test("web complex output", len(wj) > 200)
    test_contains("desktop has VERSION", dk, "VERSION")
    test_contains("web has VERSION", wj, "VERSION")
    test_contains("desktop has findItem", dk, "findItem")
    test_contains("web has findItem", wj, "findItem")


def test_integration_project_dirs():
    section("Integration — Full Project Directory Structures")

    from epl.desktop import generate_desktop_project
    from epl.wasm_web import generate_web_project
    from epl.kotlin_gen import generate_android_project

    program = _parse('Display "Multi-target"')

    # Desktop
    d_out = make_temp_dir()
    generate_desktop_project(program, d_out, app_name="DesktopApp")

    # Count files
    d_files = []
    for root, dirs, files in os.walk(d_out):
        d_files.extend(files)
    test("desktop has 10+ files", len(d_files) >= 10)

    # Web JS
    w_out = make_temp_dir()
    generate_web_project(program, w_out, app_name="WebApp", mode="js")

    w_files = []
    for root, dirs, files in os.walk(w_out):
        w_files.extend(files)
    test("web js has 7+ files", len(w_files) >= 7)

    # Web WASM
    ww_out = make_temp_dir()
    generate_web_project(program, ww_out, app_name="WasmApp", mode="wasm")

    ww_files = []
    for root, dirs, files in os.walk(ww_out):
        ww_files.extend(files)
    test("web wasm has 6+ files", len(ww_files) >= 6)

    # Android
    a_out = make_temp_dir()
    generate_android_project(program, a_out)

    a_files = []
    for root, dirs, files in os.walk(a_out):
        a_files.extend(files)
    test("android has 30+ files", len(a_files) >= 30)


def test_version_check():
    section("Version Check")
    from epl import __version__
    test("version is 7.0.0", __version__ == "7.0.0")


# ═══════════════════════════════════════════════════════════
# Expression Edge Cases
# ═══════════════════════════════════════════════════════════

def test_desktop_expression_edge_cases():
    section("6a Desktop — Expression Edge Cases")
    from epl.desktop import DesktopComposeGenerator

    gen = DesktopComposeGenerator()

    # String concatenation via BinaryOp
    concat = ast.BinaryOp(ast.Literal("Hello "), '+', ast.Identifier("name"))
    result = gen._expr(concat)
    test("string concat", "Hello" in result and "name" in result)

    # Float literal
    fl = ast.Literal(3.14)
    test("float literal", gen._expr(fl) == "3.14")

    # Nested binary
    nested = ast.BinaryOp(
        ast.BinaryOp(ast.Literal(1), '+', ast.Literal(2)),
        '*',
        ast.Literal(3)
    )
    result = gen._expr(nested)
    test("nested binary", '1' in result and '2' in result and '3' in result)

    # Boolean operators
    and_op = ast.BinaryOp(ast.Literal(True), 'and', ast.Literal(False))
    test("and operator", '&&' in gen._expr(and_op))

    or_op = ast.BinaryOp(ast.Literal(True), 'or', ast.Literal(False))
    test("or operator", '||' in gen._expr(or_op))


def test_web_js_expression_edge_cases():
    section("6c Web — JS Expression Edge Cases")
    from epl.wasm_web import WebCodeGenerator

    gen = WebCodeGenerator()

    # Power operator
    power = ast.BinaryOp(ast.Literal(2), '**', ast.Literal(10))
    result = gen._js_expr(power)
    test("power maps to Math.pow", "Math.pow" in result)

    # Floor division
    fdiv = ast.BinaryOp(ast.Literal(7), '//', ast.Literal(2))
    result = gen._js_expr(fdiv)
    test("floor div", "Math.floor" in result)

    # And/Or
    and_op = ast.BinaryOp(ast.Identifier("a"), 'and', ast.Identifier("b"))
    test("and to &&", '&&' in gen._js_expr(and_op))

    or_op = ast.BinaryOp(ast.Identifier("a"), 'or', ast.Identifier("b"))
    test("or to ||", '||' in gen._js_expr(or_op))

    # Not
    not_op = ast.UnaryOp('not', ast.Identifier("x"))
    test("not to !", '!' in gen._js_expr(not_op))

    # None/null
    test("null literal", gen._js_expr(ast.Literal(None)) == "null")

    # String escaping
    esc = ast.Literal('hello "world"')
    result = gen._js_expr(esc)
    test("string escaping", '\\"' in result)


# ═══════════════════════════════════════════════════════════
# CLI Tests
# ═══════════════════════════════════════════════════════════

def test_cli_functions_exist():
    section("CLI — Functions Exist")
    import main as epl_main

    test("generate_desktop exists", hasattr(epl_main, 'generate_desktop'))
    test("generate_web exists", hasattr(epl_main, 'generate_web'))
    test("generate_android exists", hasattr(epl_main, 'generate_android'))


# ═══════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════

def main():
    print("=" * 60)
    print("  EPL Phase 6 Test Suite — Mobile & Desktop")
    print("  Version: 7.0.0")
    print("=" * 60)

    try:
        # 6a Desktop
        test_desktop_import()
        test_desktop_generator_init()
        test_desktop_simple_program()
        test_desktop_variables()
        test_desktop_function()
        test_desktop_class()
        test_desktop_conditionals()
        test_desktop_loops()
        test_desktop_while_loop()
        test_desktop_try_catch()
        test_desktop_gui_widgets()
        test_desktop_runtime()
        test_desktop_project_generation()
        test_desktop_build_gradle_details()
        test_desktop_settings_gradle()
        test_desktop_expression_codegen()
        test_desktop_widget_types()
        test_desktop_expression_edge_cases()

        # 6b Android
        test_android_import()
        test_android_kotlin_transpile()
        test_android_variables()
        test_android_functions()
        test_android_classes()
        test_android_conditionals()
        test_android_loops()
        test_android_collections()
        test_android_try_catch()
        test_android_project_generation()
        test_android_manifest_details()
        test_android_strings_xml()
        test_android_themes()
        test_android_colors()
        test_android_gradle()
        test_android_proguard()
        test_android_symbol_table()
        test_android_gui_activity()
        test_android_compose_activity()

        # 6c Web
        test_web_import()
        test_web_js_transpile()
        test_web_js_variables()
        test_web_js_functions()
        test_web_js_conditionals()
        test_web_js_loops()
        test_web_js_classes()
        test_web_js_try_catch()
        test_web_js_collections()
        test_web_js_builtins()
        test_web_js_runtime_functions()
        test_web_html_generation()
        test_web_html_widgets()
        test_web_css_generation()
        test_web_wasm_loader()
        test_web_wasm_runtime()
        test_web_wasm_glue()
        test_web_js_project_generation()
        test_web_wasm_project_generation()
        test_web_kotlin_js_project_generation()
        test_web_kotlin_js_transpile()
        test_web_html_modes()
        test_web_pwa_support()

        # Integration
        test_integration_all_targets()
        test_integration_gui_all_targets()
        test_integration_complex_program()
        test_integration_project_dirs()
        test_version_check()

        # Expression edge cases
        test_web_js_expression_edge_cases()

        # CLI
        test_cli_functions_exist()

    finally:
        cleanup()

    print("\n" + "=" * 60)
    print(f"  Results: {passed} passed, {failed} failed, {total} total")
    print("=" * 60)

    if failed > 0:
        sys.exit(1)
    else:
        print("  ALL PHASE 6 TESTS PASSED!")


if __name__ == '__main__':
    main()
