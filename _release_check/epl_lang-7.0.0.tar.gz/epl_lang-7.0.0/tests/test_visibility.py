"""
Comprehensive visibility modifier enforcement tests for EPL v5.0.
Tests Private, Protected, and Public access control on properties and methods.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from epl.lexer import Lexer
from epl.parser import Parser
from epl.interpreter import Interpreter
from epl.errors import RuntimeError as EPLRuntimeError

passed = 0
failed = 0

def run(src):
    l = Lexer(src)
    t = l.tokenize()
    p = Parser(t)
    prog = p.parse()
    i = Interpreter()
    i.execute(prog)
    return i.output_lines

def test(name, fn):
    global passed, failed
    try:
        fn()
        passed += 1
        print(f"  PASS: {name}")
    except AssertionError as e:
        failed += 1
        print(f"  FAIL: {name} -> {e}")
    except Exception as e:
        failed += 1
        print(f"  FAIL: {name} -> {type(e).__name__}: {e}")

class AssertionError(Exception): pass

def assert_eq(a, b, msg=""):
    if a != b:
        raise AssertionError(f"Expected {b!r}, got {a!r}. {msg}")

def assert_raises(src, error_substr):
    try:
        run(src)
        raise AssertionError(f"Expected error containing '{error_substr}' but no error was raised")
    except EPLRuntimeError as e:
        if error_substr.lower() not in str(e).lower():
            raise AssertionError(f"Expected '{error_substr}' in error, got: {e}")
    except Exception as e:
        if error_substr.lower() not in str(e).lower():
            raise AssertionError(f"Expected '{error_substr}' in error, got: {type(e).__name__}: {e}")

# ═══════════════════════════════════════════════════════════
# 1. PRIVATE PROPERTIES
# ═══════════════════════════════════════════════════════════
print("\n=== Private Properties ===")

test("private_prop_blocked_from_outside", lambda: assert_raises(
    'Class Vault\nPrivate Create code equal to 1234\nEnd\nCreate v equal to new Vault()\nPrint v.code',
    'private'))

test("private_prop_read_inside_method", lambda: assert_eq(
    run('Class Vault\nPrivate Create code equal to 1234\nFunction get_code takes nothing\nReturn code\nEnd\nEnd\nCreate v equal to new Vault()\nPrint v.get_code()'),
    ['1234']))

test("private_prop_write_blocked_from_outside", lambda: assert_raises(
    'Class Vault\nPrivate Create code equal to 1234\nEnd\nCreate v equal to new Vault()\nv.code = 9999',
    'private'))

test("private_prop_set_inside_method", lambda: assert_eq(
    run('Class Counter\nPrivate Create count equal to 0\nFunction increment takes nothing\nSet count to count + 1\nEnd\nFunction get takes nothing\nReturn count\nEnd\nEnd\nCreate c equal to new Counter()\nc.increment()\nc.increment()\nPrint c.get()'),
    ['2']))

test("multiple_private_props", lambda: assert_eq(
    run('Class Pair\nPrivate Create left_val equal to "a"\nPrivate Create right_val equal to "b"\nFunction combine takes nothing\nReturn left_val + right_val\nEnd\nEnd\nCreate p equal to new Pair()\nPrint p.combine()'),
    ['ab']))

test("private_prop_not_accessible_from_other_class", lambda: assert_raises(
    'Class Secret\nPrivate Create data equal to 42\nEnd\nClass Spy\nFunction steal takes target\nReturn target.data\nEnd\nEnd\nCreate s equal to new Secret()\nCreate spy equal to new Spy()\nPrint spy.steal(s)',
    'private'))

# ═══════════════════════════════════════════════════════════
# 2. PRIVATE METHODS
# ═══════════════════════════════════════════════════════════
print("\n=== Private Methods ===")

test("private_method_blocked_from_outside", lambda: assert_raises(
    'Class Engine\nPrivate Function ignite takes nothing\nReturn "vroom"\nEnd\nEnd\nCreate e equal to new Engine()\nPrint e.ignite()',
    'private'))

test("private_method_callable_internally", lambda: assert_eq(
    run('Class Engine\nPrivate Function ignite takes nothing\nReturn "vroom"\nEnd\nFunction start takes nothing\nReturn this.ignite()\nEnd\nEnd\nCreate e equal to new Engine()\nPrint e.start()'),
    ['vroom']))

test("private_method_chain_internal", lambda: assert_eq(
    run('Class Math\nPrivate Function double takes n\nReturn n * 2\nEnd\nPrivate Function triple takes n\nReturn n * 3\nEnd\nFunction compute takes n\nReturn this.double(n) + this.triple(n)\nEnd\nEnd\nCreate m equal to new Math()\nPrint m.compute(5)'),
    ['25']))

test("private_init_still_works", lambda: assert_eq(
    run('Class Box\nPrivate Create size equal to 0\nFunction init takes s\nSet size to s\nEnd\nFunction get_size takes nothing\nReturn size\nEnd\nEnd\nCreate b equal to new Box(10)\nPrint b.get_size()'),
    ['10']))

# ═══════════════════════════════════════════════════════════
# 3. PROTECTED PROPERTIES
# ═══════════════════════════════════════════════════════════
print("\n=== Protected Properties ===")

test("protected_prop_blocked_from_outside", lambda: assert_raises(
    'Class Animal\nProtected Create species equal to "unknown"\nEnd\nCreate obj equal to new Animal()\nPrint obj.species',
    'protected'))

test("protected_prop_accessible_in_subclass", lambda: assert_eq(
    run('Class Animal\nProtected Create species equal to "unknown"\nEnd\nClass Dog extends Animal\nFunction get_species takes nothing\nReturn species\nEnd\nEnd\nCreate obj equal to new Dog()\nPrint obj.get_species()'),
    ['unknown']))

test("protected_prop_set_in_subclass", lambda: assert_eq(
    run('Class Animal\nProtected Create species equal to "unknown"\nEnd\nClass Cat extends Animal\nFunction init takes nothing\nSet species to "feline"\nEnd\nFunction get_species takes nothing\nReturn species\nEnd\nEnd\nCreate obj equal to new Cat()\nPrint obj.get_species()'),
    ['feline']))

test("protected_prop_deep_inheritance", lambda: assert_eq(
    run('Class Base\nProtected Create val equal to 100\nEnd\nClass Mid extends Base\nEnd\nClass Leaf extends Mid\nFunction get_val takes nothing\nReturn val\nEnd\nEnd\nCreate obj equal to new Leaf()\nPrint obj.get_val()'),
    ['100']))

# ═══════════════════════════════════════════════════════════
# 4. PROTECTED METHODS
# ═══════════════════════════════════════════════════════════
print("\n=== Protected Methods ===")

test("protected_method_blocked_from_outside", lambda: assert_raises(
    'Class Base\nProtected Function helper takes nothing\nReturn 42\nEnd\nEnd\nCreate obj equal to new Base()\nPrint obj.helper()',
    'protected'))

test("protected_method_callable_from_subclass", lambda: assert_eq(
    run('Class Base\nProtected Function helper takes nothing\nReturn 42\nEnd\nEnd\nClass Child extends Base\nFunction compute takes nothing\nReturn this.helper()\nEnd\nEnd\nCreate obj equal to new Child()\nPrint obj.compute()'),
    ['42']))

# ═══════════════════════════════════════════════════════════
# 5. PUBLIC ACCESS
# ═══════════════════════════════════════════════════════════
print("\n=== Public Access ===")

test("explicit_public_prop", lambda: assert_eq(
    run('Class Person\nPublic Create nickname equal to "Joe"\nEnd\nCreate obj equal to new Person()\nPrint obj.nickname'),
    ['Joe']))

test("explicit_public_method", lambda: assert_eq(
    run('Class Greeter\nPublic Function greet takes nothing\nReturn "hello"\nEnd\nEnd\nCreate obj equal to new Greeter()\nPrint obj.greet()'),
    ['hello']))

test("default_is_public_prop", lambda: assert_eq(
    run('Class Open\nCreate field equal to "visible"\nEnd\nCreate obj equal to new Open()\nPrint obj.field'),
    ['visible']))

test("default_is_public_method", lambda: assert_eq(
    run('Class Open\nFunction method takes nothing\nReturn "ok"\nEnd\nEnd\nCreate obj equal to new Open()\nPrint obj.method()'),
    ['ok']))

test("public_prop_set_from_outside", lambda: assert_eq(
    run('Class Mutable\nPublic Create val equal to 1\nEnd\nCreate obj equal to new Mutable()\nobj.val = 99\nPrint obj.val'),
    ['99']))

# ═══════════════════════════════════════════════════════════
# 6. MIXED VISIBILITY
# ═══════════════════════════════════════════════════════════
print("\n=== Mixed Visibility ===")

test("mixed_public_private_props", lambda: assert_eq(
    run('Class Account\nPublic Create owner equal to "Alice"\nPrivate Create balance equal to 1000\nFunction get_balance takes nothing\nReturn balance\nEnd\nEnd\nCreate acc equal to new Account()\nPrint acc.owner\nPrint acc.get_balance()'),
    ['Alice', '1000']))

test("mixed_public_private_methods", lambda: assert_eq(
    run('Class Service\nPrivate Function validate takes nothing\nReturn true\nEnd\nPublic Function process takes nothing\nIf this.validate()\nReturn "done"\nEnd\nReturn "fail"\nEnd\nEnd\nCreate svc equal to new Service()\nPrint svc.process()'),
    ['done']))

test("mixed_private_prop_public_method_blocks", lambda: assert_raises(
    'Class Safe\nPrivate Create pin equal to 1234\nPublic Function check takes guess\nReturn guess == pin\nEnd\nEnd\nCreate obj equal to new Safe()\nPrint obj.pin',
    'private'))

test("inherited_public_stays_public", lambda: assert_eq(
    run('Class Base\nPublic Create tag equal to "base"\nEnd\nClass Child extends Base\nEnd\nCreate obj equal to new Child()\nPrint obj.tag'),
    ['base']))

test("inherited_private_stays_private", lambda: assert_raises(
    'Class Base\nPrivate Create secret equal to "hidden"\nEnd\nClass Child extends Base\nEnd\nCreate obj equal to new Child()\nPrint obj.secret',
    'private'))

# ═══════════════════════════════════════════════════════════
# 7. EDGE CASES
# ═══════════════════════════════════════════════════════════
print("\n=== Edge Cases ===")

test("this_access_to_private_prop", lambda: assert_eq(
    run('Class Obj\nPrivate Create val equal to 7\nFunction get_val takes nothing\nReturn this.val\nEnd\nEnd\nCreate obj equal to new Obj()\nPrint obj.get_val()'),
    ['7']))

test("this_set_private_prop", lambda: assert_eq(
    run('Class Obj\nPrivate Create val equal to 0\nFunction set_val takes v\nSet val to v\nEnd\nFunction get_val takes nothing\nReturn val\nEnd\nEnd\nCreate obj equal to new Obj()\nobj.set_val(42)\nPrint obj.get_val()'),
    ['42']))

test("private_method_with_private_prop", lambda: assert_eq(
    run('Class Calc\nPrivate Create state equal to 0\nPrivate Function compute takes n\nReturn n * 2\nEnd\nFunction run_calc takes n\nReturn this.compute(n)\nEnd\nEnd\nCreate calc equal to new Calc()\nPrint calc.run_calc(5)'),
    ['10']))

test("no_visibility_on_builtin_methods", lambda: assert_eq(
    run('Class Holder\nCreate items equal to [1, 2, 3]\nEnd\nCreate obj equal to new Holder()\nPrint obj.items.length'),
    ['3']))

test("multiple_instances_same_visibility", lambda: assert_eq(
    run('Class Thing\nPrivate Create id_val equal to 0\nFunction init takes n\nSet id_val to n\nEnd\nFunction get_id takes nothing\nReturn id_val\nEnd\nEnd\nCreate t1 equal to new Thing(1)\nCreate t2 equal to new Thing(2)\nPrint t1.get_id()\nPrint t2.get_id()'),
    ['1', '2']))

# ═══════════════════════════════════════════════════════════
# RESULTS
# ═══════════════════════════════════════════════════════════
print(f"\n{'='*50}")
print(f"Visibility Tests: {passed}/{passed+failed} passed, {failed} failed")
print(f"{'='*50}")
if failed:
    sys.exit(1)
