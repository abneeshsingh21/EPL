"""Quick verification of strict type system hardening."""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from epl.type_system import TypeChecker
from epl.lexer import Lexer
from epl.parser import Parser


def check(code, strict=True):
    tokens = Lexer(code).tokenize()
    tree = Parser(tokens).parse()
    tc = TypeChecker(strict=strict)
    return tc.check(tree)


# Test 1: return type mismatch
code1 = 'Function add takes a and returns integer\n    return "hello"\nEnd Function'
diags = check(code1)
assert any("Return type" in d.message and "error" == d.level for d in diags), f"Expected return type error, got: {diags}"
print("PASS: return type mismatch detected")

# Test 2: unreachable code
code2 = 'Function foo\n    return 10\n    print 20\nEnd Function'
diags = check(code2)
assert any("Unreachable" in d.message for d in diags), f"Expected unreachable warning, got: {diags}"
print("PASS: unreachable code detected")

# Test 3: too many arguments
code3 = 'Function greet takes name\n    print name\nEnd Function\ngreet("Alice", "extra")'
diags = check(code3)
assert any("Too many arguments" in d.message for d in diags), f"Expected too many args warning, got: {diags}"
print("PASS: too many arguments detected")

# Test 4: undeclared variable (strict)
code4 = 'print unknownVar'
diags = check(code4)
assert any("before declaration" in d.message for d in diags), f"Expected undeclared var error, got: {diags}"
print("PASS: undeclared variable detected")

# Test 5: type mismatch in assignment
code5 = 'create integer x as 10\nset x to "hello"'
diags = check(code5)
assert any("Cannot assign" in d.message for d in diags), f"Expected type mismatch error, got: {diags}"
print("PASS: type mismatch in assignment detected")

# Test 6: no false positives on valid code
code6 = 'create x as 10\nset x to 20\nprint x'
diags = check(code6)
errors = [d for d in diags if d.level == "error"]
assert len(errors) == 0, f"Expected no errors on valid code, got: {errors}"
print("PASS: no false positives on valid code")

# Test 7: d.level field works (not d.severity)
code7 = 'print unknownVar'
diags = check(code7)
for d in diags:
    assert hasattr(d, 'level'), "TypeDiagnostic should have 'level' field"
    assert d.level in ("error", "warning", "info"), f"Invalid level: {d.level}"
print("PASS: TypeDiagnostic uses .level correctly")

print("\nAll strict type system hardening tests passed!")
