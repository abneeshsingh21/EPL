"""
EPL Stability Tests — Edge Cases and Error Handling
Tests that the interpreter correctly handles edge cases without crashing.
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from epl.lexer import Lexer
from epl.parser import Parser
from epl.interpreter import Interpreter
from epl.errors import EPLError

passed = 0
failed = 0


def run_epl(code):
    """Run EPL code and return (output, error)."""
    import io
    old_stdout = sys.stdout
    sys.stdout = io.StringIO()
    error = None
    try:
        lexer = Lexer(code)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        ast = parser.parse()
        interp = Interpreter()
        interp.execute(ast)
    except EPLError as e:
        error = str(e)
    except Exception as e:
        error = f"PYTHON CRASH: {type(e).__name__}: {e}"
    output = sys.stdout.getvalue()
    sys.stdout = old_stdout
    return output.strip(), error


def check_output(name, code, expected):
    global passed, failed
    out, err = run_epl(code)
    if err:
        print(f"  FAIL: {name} — unexpected error: {err}")
        failed += 1
    elif out == expected:
        print(f"  PASS: {name}")
        passed += 1
    else:
        print(f"  FAIL: {name} — got '{out}', expected '{expected}'")
        failed += 1


def check_error(name, code, keyword=None):
    """Verify code produces a clean EPL error (not a Python crash)."""
    global passed, failed
    out, err = run_epl(code)
    if err and "PYTHON CRASH" in err:
        print(f"  FAIL: {name} — Python crash instead of EPL error: {err}")
        failed += 1
    elif err:
        if keyword and keyword.lower() not in err.lower():
            print(f"  FAIL: {name} — error doesn't mention '{keyword}': {err}")
            failed += 1
        else:
            print(f"  PASS: {name}")
            passed += 1
    else:
        print(f"  FAIL: {name} — expected error but got output: '{out}'")
        failed += 1


print("=== EPL Stability Tests ===\n")

# ═══════════════════════════════════════════════════════════
#  1. Builtin Function Edge Cases
# ═══════════════════════════════════════════════════════════
print("--- Builtin Edge Cases ---")

check_error("max_empty_list", 'Print max([])', 'empty')
check_error("min_empty_list", 'Print min([])', 'empty')
check_error("sum_non_numeric", '''
Create items equal to ["a", "b"]
Print sum(items)
''', 'numeric')
check_error("sorted_mixed_types", '''
Create items equal to [3, "hello", 1]
Print sorted(items)
''', 'same type')
check_error("sqrt_negative", 'Print sqrt(-1)', 'negative')
check_error("log_zero", 'Print log(0)', 'positive')
check_error("log_negative", 'Print log(-5)', 'positive')
check_error("round_non_numeric", 'Print round("hello")', 'number')

# Working cases still work
check_output("max_normal", 'Print max(3, 7, 2)', '7')
check_output("min_normal", 'Print min(3, 7, 2)', '2')
check_output("sum_normal", 'Print sum([1, 2, 3])', '6')
check_output("sorted_normal", 'Print sorted([3, 1, 2])', '[1, 2, 3]')
check_output("sqrt_normal", 'Print sqrt(16)', '4.0')
check_output("round_normal", 'Print round(3.7)', '4')

# ═══════════════════════════════════════════════════════════
#  2. Short-Circuit And/Or
# ═══════════════════════════════════════════════════════════
print("\n--- Short-Circuit Evaluation ---")

check_output("and_short_circuit", '''
Create items equal to []
If length(items) > 0 and items[0] == "hello" Then
    Print "found"
Otherwise
    Print "safe"
End
''', 'safe')

check_output("or_short_circuit", '''
Create x equal to 5
If x > 0 or x / 0 > 1 Then
    Print "safe"
End
''', 'safe')

check_output("and_both_true", '''
If true and true Then
    Print "yes"
End
''', 'yes')

check_output("or_both_false", '''
If false or false Then
    Print "yes"
Otherwise
    Print "no"
End
''', 'no')

# ═══════════════════════════════════════════════════════════
#  3. Repeat Edge Cases
# ═══════════════════════════════════════════════════════════
print("\n--- Repeat Edge Cases ---")

check_error("repeat_negative", '''
Repeat -3 times
    Print "hello"
End
''', 'negative')

check_output("repeat_zero", '''
Create count equal to 0
Repeat count times
    Print "hello"
End
Print "done"
''', 'done')

# ═══════════════════════════════════════════════════════════
#  4. Reduce Edge Cases
# ═══════════════════════════════════════════════════════════
print("\n--- Reduce Edge Cases ---")

check_error("reduce_empty_no_init", '''
Create items equal to []
Create fn equal to lambda a, b -> a + b
Print items.reduce(fn)
''', 'empty')

check_output("reduce_with_init", '''
Create items equal to []
Create fn equal to lambda a, b -> a + b
Print items.reduce(fn, 0)
''', '0')

check_output("reduce_normal", '''
Create items equal to [1, 2, 3, 4]
Create fn equal to lambda a, b -> a + b
Print items.reduce(fn)
''', '10')

# ═══════════════════════════════════════════════════════════
#  5. Power Overflow Protection
# ═══════════════════════════════════════════════════════════
print("\n--- Power Overflow ---")

check_error("power_huge_exponent", '''
Create x equal to 10 ** 1000000000
''', 'too large')

check_output("power_normal", 'Print 2 ** 10', '1024')

# ═══════════════════════════════════════════════════════════
#  6. Division Edge Cases (already handled, verify)
# ═══════════════════════════════════════════════════════════
print("\n--- Division Edge Cases ---")

check_error("div_by_zero", 'Print 10 / 0', 'zero')
check_error("mod_by_zero", 'Print 10 % 0', 'zero')
check_error("floor_div_by_zero", 'Print 10 // 0', 'zero')
check_output("div_normal", 'Print 10 / 2', '5')

# ═══════════════════════════════════════════════════════════
#  7. Empty Collections
# ═══════════════════════════════════════════════════════════
print("\n--- Empty Collections ---")

check_output("empty_list_length", '''
Create items equal to []
Print length(items)
''', '0')

check_output("empty_list_foreach", '''
Create items equal to []
For each item in items
    Print item
End
Print "done"
''', 'done')

check_output("empty_string", '''
Create s equal to ""
Print length(s)
''', '0')

# ═══════════════════════════════════════════════════════════
#  8. Type Coercion Safety
# ═══════════════════════════════════════════════════════════
print("\n--- Type Safety ---")

check_error("add_bool_to_int", '''
Create x equal to 5 - true
''', '')

check_output("string_concat_with_num", '''
Create x equal to "age: " + 25
Print x
''', 'age: 25')

check_output("string_concat_with_bool", '''
Create x equal to "flag: " + true
Print x
''', 'flag: true')

# ═══════════════════════════════════════════════════════════
#  9. Recursive Depth (limited test)
# ═══════════════════════════════════════════════════════════
print("\n--- Recursion ---")

check_output("recursion_normal", '''
Function fib takes n
    If n <= 1 Then
        Return n
    End
    Return fib(n - 1) + fib(n - 2)
End
Print fib(10)
''', '55')

# ═══════════════════════════════════════════════════════════
#  10. Index Bounds
# ═══════════════════════════════════════════════════════════
print("\n--- Index Bounds ---")

check_error("list_index_out", '''
Create items equal to [1, 2, 3]
Print items[5]
''', 'out of range')

check_error("list_negative_index", '''
Create items equal to [1, 2, 3]
Print items[-1]
''', 'out of range')

check_error("string_index_out", '''
Create s equal to "abc"
Print s[10]
''', 'out of range')

# ═══════════════════════════════════════════════════════════
#  11. Multiple Operations Chained
# ═══════════════════════════════════════════════════════════
print("\n--- Complex Expressions ---")

check_output("chained_math", 'Print 2 + 3 * 4 - 1', '13')
check_output("nested_function_calls", 'Print absolute(0 - max(3, 7, 2))', '7')
check_output("list_method_chain", '''
Create items equal to [5, 3, 1, 4, 2]
Print sorted(items)
''', '[1, 2, 3, 4, 5]')

# ═══════════════════════════════════════════════════════════
#  Results
# ═══════════════════════════════════════════════════════════

print(f"\n{'='*50}")
print(f"Stability Tests: {passed}/{passed+failed} passed, {failed} failed")
print(f"{'='*50}")

if failed > 0:
    sys.exit(1)
