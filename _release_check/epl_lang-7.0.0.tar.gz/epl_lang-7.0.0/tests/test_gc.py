"""EPL Garbage Collection Tests — LLVM Compiler GC Integration."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from epl.lexer import Lexer
from epl.parser import Parser
from epl.compiler import Compiler


def compile_epl(src):
    l = Lexer(src)
    t = l.tokenize()
    p = Parser(t)
    prog = p.parse()
    c = Compiler()
    return c.compile(prog)


passed = 0
failed = 0


def check(name, condition):
    global passed, failed
    if condition:
        print(f"  PASS: {name}")
        passed += 1
    else:
        print(f"  FAIL: {name}")
        failed += 1


print("=== GC Runtime Functions ===")
ir = compile_epl("x = 10\nPrint x\n")
for fn in ['epl_gc_collect_if_needed', 'epl_gc_shutdown', 'epl_gc_root_push',
           'epl_gc_root_pop', 'epl_gc_new_list', 'epl_gc_new_map',
           'epl_gc_new_object', 'epl_gc_new_string', 'epl_gc_collect']:
    check(f"declares {fn}", fn in ir)

check("gc_shutdown called at exit", 'epl_gc_shutdown' in ir and 'call void' in ir)

print("\n=== GC List Allocation ===")
ir = compile_epl("items = [1, 2, 3]\n")
check("list uses gc_new_list", 'epl_gc_new_list' in ir)
check("list root pushed", 'epl_gc_root_push' in ir)
check("no old epl_list_new call", 'call i8* @"epl_list_new"' not in ir)

print("\n=== GC Map Allocation ===")
ir = compile_epl('p = Map with name = "test" and age = 20\n')
check("map uses gc_new_map", 'epl_gc_new_map' in ir)
check("map root pushed", 'epl_gc_root_push' in ir)

print("\n=== GC Object Allocation ===")
ir = compile_epl("Class Dog\n    name = \"Rex\"\nEnd\nd = new Dog\n")
check("object uses gc_new_object", 'epl_gc_new_object' in ir)
check("object root pushed", 'epl_gc_root_push' in ir)

print("\n=== GC Loop Safepoints ===")
ir = compile_epl("Repeat 5 times\n    Print 1\nEnd\n")
check("repeat has safepoint", 'epl_gc_collect_if_needed' in ir)

ir = compile_epl("x = 1\nWhile x < 10\n    x = x + 1\nEnd\n")
check("while has safepoint", 'epl_gc_collect_if_needed' in ir)

ir = compile_epl("For i from 1 to 10\n    Print i\nEnd\n")
check("for-range has safepoint", 'epl_gc_collect_if_needed' in ir)

ir = compile_epl("items = [1,2,3]\nFor each item in items\n    Print item\nEnd\n")
check("for-each has safepoint", 'epl_gc_collect_if_needed' in ir)

print("\n=== GC Function Root Management ===")
ir = compile_epl("Function greet takes n\n    items = [1,2]\n    Return items\nEnd\n")
check("function: root push for list", 'epl_gc_root_push' in ir)
check("function: root pop on return", 'epl_gc_root_pop' in ir)

print("\n=== GC Complex Programs ===")
ir = compile_epl("items = [1,2,3]\nFor i from 1 to 5\n    items = [i, i+1]\nEnd\n")
check("loop+list: gc_new_list present", 'epl_gc_new_list' in ir)
check("loop+list: safepoint present", 'epl_gc_collect_if_needed' in ir)
check("loop+list: root push present", 'epl_gc_root_push' in ir)

ir = compile_epl("Class Cat\n    name = \"Whiskers\"\nEnd\ncats = [1,2,3]\nc = new Cat\n")
check("class+list: both gc allocations", 'epl_gc_new_list' in ir and 'epl_gc_new_object' in ir)

print(f"\n{'='*50}")
print(f"GC Results: {passed} passed, {failed} failed (total {passed+failed})")
if failed == 0:
    print("All GC tests PASSED!")
else:
    print(f"WARNING: {failed} test(s) FAILED!")
    sys.exit(1)
