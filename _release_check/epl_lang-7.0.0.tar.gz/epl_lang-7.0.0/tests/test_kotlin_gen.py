"""
Tests for EPL Kotlin Generator (epl/kotlin_gen.py)
Validates that EPL source → Kotlin output is correct.
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from epl.lexer import Lexer
from epl.parser import Parser
from epl.kotlin_gen import KotlinGenerator, transpile_to_kotlin

passed = 0
failed = 0


def check(name, fn):
    global passed, failed
    try:
        result = fn()
        if result:
            print(f"  PASS: {name}")
            passed += 1
        else:
            print(f"  FAIL: {name}")
            failed += 1
    except Exception as e:
        print(f"  FAIL: {name} — {e}")
        failed += 1


def to_kt(src):
    tokens = Lexer(src).tokenize()
    program = Parser(tokens).parse()
    return transpile_to_kotlin(program)


print("=== Kotlin Generator Tests ===\n")

# --- Package & main ---
check("has_package", lambda: 'package com.epl.app' in to_kt('Print "Hello"'))
check("has_main", lambda: 'fun main()' in to_kt('Print "Hello"'))

# --- Print ---
check("print_string", lambda: 'println("Hello")' in to_kt('Print "Hello"'))
check("print_expr", lambda: 'println((5 + 3))' in to_kt('Print 5 + 3'))
check("say_alias", lambda: 'println("hi")' in to_kt('Say "hi"'))

# --- Variables ---
check("var_decl", lambda: 'var x' in to_kt('x = 10') and '= 10' in to_kt('x = 10'))
check("var_str", lambda: 'var name' in to_kt('name = "Alice"') and '"Alice"' in to_kt('name = "Alice"'))
check("var_list", lambda: 'mutableListOf(1, 2, 3)' in to_kt('items = [1, 2, 3]'))
check("var_bool", lambda: 'var flag' in to_kt('flag = true') and 'true' in to_kt('flag = true'))
check("var_assign", lambda: 'x = ' in to_kt('x = 10\nSet x to 20'))

# --- If / Else ---
kt_if = to_kt('If x > 5 then\n  Print "big"\nEnd')
check("if_stmt", lambda: 'if (' in kt_if and 'println("big")' in kt_if)

kt_if_else = to_kt('If x > 5 then\n  Print "big"\nOtherwise\n  Print "small"\nEnd')
check("if_else", lambda: '} else {' in kt_if_else)

# --- Loops ---
check("while_loop", lambda: 'while (' in to_kt('While x < 10\n  x += 1\nEnd'))
check("repeat_loop", lambda: 'repeat(' in to_kt('Repeat 5 times\n  Print "hi"\nEnd'))
check("for_range", lambda: 'for (i in 1..10)' in to_kt('For i from 1 to 10\n  Print i\nEnd'))
check("for_range_step", lambda: 'step 2' in to_kt('For i from 0 to 10 step 2\n  Print i\nEnd'))
check("for_range_neg_step", lambda: 'downTo' in to_kt('For i from 5 to 1 step -1\n  Print i\nEnd'))
check("for_each", lambda: 'for (item in' in to_kt('items = [1, 2, 3]\nFor each item in items\n  Print item\nEnd'))

# --- Functions ---
kt_fn = to_kt('Function greet takes name\n  Print "Hello " + name\nEnd')
check("func_def", lambda: 'fun greet(' in kt_fn)
check("func_param_type", lambda: 'name: Any' in kt_fn)
check("func_outside_main", lambda: kt_fn.index('fun greet') < kt_fn.index('fun main') if 'fun main' in kt_fn else 'fun greet' in kt_fn)

kt_fn2 = to_kt('Function add takes a and b\n  Return a + b\nEnd')
check("func_return", lambda: 'return (a + b)' in kt_fn2)

# --- Function calls ---
kt_call = to_kt('Function sum takes a and b\n  Return a + b\nEnd\nresult = call sum with 3 and 4')
check("func_call", lambda: 'sum(3, 4)' in kt_call)

# --- Try / Catch ---
kt_tc = to_kt('Try\n  Print 42\nCatch e\n  Print e\nEnd')
check("try_catch", lambda: 'try {' in kt_tc and 'catch' in kt_tc)

# --- Throw ---
check("throw_stmt", lambda: 'throw' in to_kt('Throw "oops"'))

# --- Match / When ---
kt_match = to_kt('x = 2\nMatch x\n  When 1\n    Print "one"\n  When 2\n    Print "two"\nEnd')
check("match_when", lambda: 'when' in kt_match)

# --- Enum ---
kt_enum = to_kt('Enum Color as RED, GREEN, BLUE')
check("enum_class", lambda: 'enum class Color' in kt_enum or 'Color' in kt_enum)
check("enum_members", lambda: 'RED' in kt_enum and 'GREEN' in kt_enum and 'BLUE' in kt_enum)

# --- Classes ---
kt_class = to_kt('Class Dog\n  name = "Rex"\nEnd')
check("class_def", lambda: 'class Dog' in kt_class or 'Dog' in kt_class)

# --- Constants ---
check("const_decl", lambda: 'val' in to_kt('Constant PI = 3.14'))

# --- Augmented Assignment ---
check("aug_plus", lambda: 'x += 5' in to_kt('x = 10\nx += 5'))
check("aug_minus", lambda: 'x -= 3' in to_kt('x = 10\nx -= 3'))

# --- Ternary ---
check("ternary", lambda: 'if' in to_kt('x = 10\ny = "big" if x > 5 otherwise "small"'))

# --- Break / Continue ---
check("break_stmt", lambda: 'break' in to_kt('While true\n  Break\nEnd'))
check("continue_stmt", lambda: 'continue' in to_kt('For i from 1 to 10\n  Continue\nEnd'))

# --- Lambda ---
check("lambda_expr", lambda: '->' in to_kt('double = lambda x -> x * 2') or 'fun' in to_kt('double = lambda x -> x * 2'))

# --- Assert ---
check("assert_stmt", lambda: 'assert' in to_kt('Assert 1 == 1').lower() or 'require' in to_kt('Assert 1 == 1'))

print(f"\n=== Kotlin Generator Results: {passed}/{passed+failed} passed, {failed} failed ===")

if failed > 0:
    sys.exit(1)
