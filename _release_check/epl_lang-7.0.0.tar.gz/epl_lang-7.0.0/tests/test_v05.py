"""Quick verification of v0.5 parser/interpreter changes."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from epl.lexer import Lexer
from epl.parser import Parser
from epl.interpreter import Interpreter

def parse(src):
    l = Lexer(src)
    t = l.tokenize()
    p = Parser(t)
    return p.parse()

# Test Store parsing
prog = parse('Store form "task" in "tasks"')
s = prog.statements[0]
print(f"Store form parse: {s.__class__.__name__} collection={s.collection} field={s.field_name}")

# Test Delete parsing
prog = parse('Delete from "tasks" at 0')
s = prog.statements[0]
print(f"Delete parse: {s.__class__.__name__} collection={s.collection}")

# Test Fetch parsing
prog = parse('Fetch "tasks"')
s = prog.statements[0]
print(f"Fetch parse: {s.__class__.__name__} collection={s.collection}")

# Test Redirect parsing
prog = parse('Redirect to "/home"')
s = prog.statements[0]
print(f"Redirect parse: {s.__class__.__name__} type={s.response_type}")

# Test interpreter doesn't crash on these
interp = Interpreter()
for src in ['Store form "task" in "tasks"', 'Delete from "tasks" at 0', 'Fetch "tasks"', 'Redirect to "/home"']:
    prog = parse(src)
    interp.execute(prog)
print("All 4 new statement types execute without errors")

# Test full todo.epl parsing (no execution - would start server)
with open('examples/todo.epl') as f:
    source = f.read()
prog = parse(source)
print(f"\ntodo.epl parsed: {len(prog.statements)} statements")
for s in prog.statements:
    name = s.__class__.__name__
    extra = ""
    if hasattr(s, 'path'): extra += f" path={s.path}"
    if hasattr(s, 'name'): extra += f" name={s.name}"
    if hasattr(s, 'app_name'): extra += f" app={s.app_name}"
    print(f"  {name}{extra}")

print("\nv0.5 verification PASSED")
