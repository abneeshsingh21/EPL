"""Test the running To-Do web app."""
import urllib.request
import urllib.parse

BASE = "http://localhost:3000"

# Test 1: GET / (empty state)
try:
    r = urllib.request.urlopen(f"{BASE}/")
    print(f"GET /: {r.status}")
    html = r.read().decode()
    print(f"  Has 'EPL To-Do': {'EPL To-Do' in html}")
    print(f"  Has '0 task(s)': {'0 task(s)' in html}")
    print(f"  Has 'No items yet': {'No items yet' in html}")
except Exception as e:
    print(f"GET / FAILED: {e}")

# Test 2: POST / (add task "Buy groceries")
try:
    data = urllib.parse.urlencode({"task": "Buy groceries"}).encode()
    req = urllib.request.Request(f"{BASE}/", data=data, method="POST")
    r = urllib.request.urlopen(req)
    print(f"POST / (add 'Buy groceries'): {r.status}")
    html = r.read().decode()
    print(f"  Has 'Buy groceries': {'Buy groceries' in html}")
    print(f"  Has '1 task(s)': {'1 task(s)' in html}")
except Exception as e:
    print(f"POST / FAILED: {e}")

# Test 3: POST / (add another task "Walk the dog")
try:
    data = urllib.parse.urlencode({"task": "Walk the dog"}).encode()
    req = urllib.request.Request(f"{BASE}/", data=data, method="POST")
    r = urllib.request.urlopen(req)
    print(f"POST / (add 'Walk the dog'): {r.status}")
    html = r.read().decode()
    print(f"  Has 'Buy groceries': {'Buy groceries' in html}")
    print(f"  Has 'Walk the dog': {'Walk the dog' in html}")
    print(f"  Has '2 task(s)': {'2 task(s)' in html}")
except Exception as e:
    print(f"POST / FAILED: {e}")

# Test 4: POST /delete (delete first task)
try:
    data = urllib.parse.urlencode({"index": "0"}).encode()
    req = urllib.request.Request(f"{BASE}/delete", data=data, method="POST")
    r = urllib.request.urlopen(req)
    print(f"POST /delete (index=0): {r.status} -> {r.url}")
    html = r.read().decode()
    has_buy = 'Buy groceries' in html
    has_walk = 'Walk the dog' in html
    print(f"  Has 'Buy groceries': {has_buy} (should be False)")
    print(f"  Has 'Walk the dog': {has_walk} (should be True)")
except Exception as e:
    print(f"POST /delete FAILED: {e}")

# Test 5: GET /about
try:
    r = urllib.request.urlopen(f"{BASE}/about")
    print(f"GET /about: {r.status}")
    html = r.read().decode()
    print(f"  Has 'About EPL': {'About EPL' in html}")
except Exception as e:
    print(f"GET /about FAILED: {e}")

# Test 6: GET /api/tasks
try:
    r = urllib.request.urlopen(f"{BASE}/api/tasks")
    print(f"GET /api/tasks: {r.status}")
    data = r.read().decode()
    print(f"  Response: {data[:200]}")
except Exception as e:
    print(f"GET /api/tasks FAILED: {e}")

print("\nAll web app tests done!")
