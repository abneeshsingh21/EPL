"""
Tests for EPL JavaScript Transpiler (epl/js_transpiler.py)
Validates that EPL source → JavaScript output is correct.
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from epl.lexer import Lexer
from epl.parser import Parser
from epl.js_transpiler import JSTranspiler, transpile_to_js, transpile_to_node

passed = 0
failed = 0


def check(name, fn):
    global passed, failed
    try:
        result = fn()
        if result:
            print(f"  PASS: {name}")
            passed += 1
        else:
            print(f"  FAIL: {name}")
            failed += 1
    except Exception as e:
        print(f"  FAIL: {name} — {e}")
        failed += 1


def to_js(src):
    tokens = Lexer(src).tokenize()
    program = Parser(tokens).parse()
    return transpile_to_js(program)


def to_node(src):
    tokens = Lexer(src).tokenize()
    program = Parser(tokens).parse()
    return transpile_to_node(program)


print("=== JS Transpiler Tests ===\n")

# --- Print / Output ---
check("print_string", lambda: 'console.log("Hello")' in to_js('Print "Hello"'))
check("print_expr", lambda: 'console.log((5 + 3))' in to_js('Print 5 + 3'))
check("say_alias", lambda: 'console.log("hi")' in to_js('Say "hi"'))

# --- Variables ---
check("var_decl_let", lambda: 'let x = 10;' in to_js('x = 10'))
check("var_decl_str", lambda: 'let name = "Alice";' in to_js('name = "Alice"'))
check("var_assign", lambda: 'x = 20;' in to_js('x = 10\nSet x to 20'))
check("var_list", lambda: 'let items = [1, 2, 3];' in to_js('items = [1, 2, 3]'))
check("var_bool", lambda: 'let flag = true;' in to_js('flag = true'))

# --- Arithmetic in expressions ---
check("expr_add", lambda: '(5 + 3)' in to_js('Print 5 + 3'))
check("expr_mul", lambda: '(6 * 7)' in to_js('Print 6 * 7'))
check("expr_mod", lambda: '(10 % 3)' in to_js('Print 10 % 3'))
check("expr_power", lambda: 'Math.pow(2, 10)' in to_js('Print 2 ** 10') or '**' in to_js('Print 2 ** 10'))

# --- If / Else ---
js_if = to_js('If x > 5 then\n  Print "big"\nEnd')
check("if_statement", lambda: 'if (' in js_if and 'console.log("big")' in js_if)

js_if_else = to_js('If x > 5 then\n  Print "big"\nOtherwise\n  Print "small"\nEnd')
check("if_else", lambda: '} else {' in js_if_else)

# --- Loops ---
check("while_loop", lambda: 'while (' in to_js('While x < 10\n  x += 1\nEnd'))
check("repeat_loop", lambda: 'for (let _i' in to_js('Repeat 5 times\n  Print "hi"\nEnd') and '< 5;' in to_js('Repeat 5 times\n  Print "hi"\nEnd'))
check("for_range", lambda: 'for (let i = 1; i <= 10; i += 1)' in to_js('For i from 1 to 10\n  Print i\nEnd'))
check("for_range_step", lambda: 'i += 2' in to_js('For i from 0 to 10 step 2\n  Print i\nEnd'))
check("for_range_neg_step", lambda: 'i >= 1' in to_js('For i from 5 to 1 step -1\n  Print i\nEnd'))
check("for_each", lambda: 'for (let item of' in to_js('items = [1, 2, 3]\nFor each item in items\n  Print item\nEnd'))

# --- Functions ---
js_fn = to_js('Function greet takes name\n  Print "Hello " + name\nEnd')
check("func_def", lambda: 'function greet(name)' in js_fn)
check("func_body_print", lambda: 'console.log' in js_fn)

js_fn2 = to_js('Function add takes a and b\n  Return a + b\nEnd')
check("func_return", lambda: 'return (a + b)' in js_fn2)

# --- Function call (user-defined priority) ---
js_call = to_js('Function sum takes a and b\n  Return a + b\nEnd\nresult = call sum with 3 and 4')
check("func_call_user", lambda: 'sum(3, 4)' in js_call)

# --- Builtins ---
check("builtin_length", lambda: '.length' in to_js('Print length("hello")'))
check("builtin_sqrt", lambda: 'Math.sqrt' in to_js('Print sqrt(16)'))
check("builtin_floor", lambda: 'Math.floor' in to_js('Print floor(3.7)'))
check("builtin_ceil", lambda: 'Math.ceil' in to_js('Print ceil(3.2)'))
check("builtin_abs", lambda: 'Math.abs' in to_js('Print absolute(-5)'))
check("builtin_max", lambda: 'Math.max' in to_js('Print max(3, 7)'))
check("builtin_round", lambda: 'Math.round' in to_js('Print round(3.5)'))
check("builtin_type_of", lambda: 'typeof' in to_js('Print type_of(42)'))
check("builtin_to_int", lambda: 'parseInt' in to_js('Print to_integer("42")'))
check("builtin_to_text", lambda: 'String(' in to_js('Print to_text(42)'))
check("builtin_random", lambda: 'Math.random()' in to_js('x = random()'))

# --- range() ---
check("range_1arg", lambda: 'Array.from({length: 5}' in to_js('x = range(5)'))
check("range_2arg", lambda: '5 - 2' in to_js('x = range(2, 5)'))

# --- String methods ---
check("str_upper", lambda: '.toUpperCase()' in to_js('x = "hello"\nPrint x.upper()'))
check("str_lower", lambda: '.toLowerCase()' in to_js('x = "HELLO"\nPrint x.lower()'))
check("str_trim", lambda: '.trim()' in to_js('x = "  hi  "\nPrint x.trim()'))
check("str_contains", lambda: '.includes(' in to_js('x = "hello"\nPrint x.contains("ell")'))
check("str_replace", lambda: '.replace(' in to_js('x = "hello"\nPrint x.replace("l", "r")'))
check("str_split", lambda: '.split(' in to_js('x = "a,b,c"\nPrint x.split(",")'))
check("str_starts_with", lambda: '.startsWith(' in to_js('x = "hello"\nPrint x.starts_with("hel")'))
check("str_ends_with", lambda: '.endsWith(' in to_js('x = "hello"\nPrint x.ends_with("lo")'))

# --- List methods ---
check("list_add", lambda: '.push(' in to_js('items = [1]\nitems.add(2)'))
check("list_sort", lambda: '.sort(' in to_js('items = [3, 1, 2]\nitems.sort()'))
check("list_reverse", lambda: '.reverse()' in to_js('items = [1, 2, 3]\nitems.reverse()'))

# --- Augmented assignment ---
check("aug_plus", lambda: 'x += 5;' in to_js('x = 10\nx += 5'))
check("aug_minus", lambda: 'x -= 3;' in to_js('x = 10\nx -= 3'))
check("aug_mul", lambda: 'x *= 2;' in to_js('x = 10\nx *= 2'))
check("aug_div", lambda: 'x /= 2;' in to_js('x = 10\nx /= 2'))

# --- Ternary ---
check("ternary", lambda: '?' in to_js('x = 10\ny = "big" if x > 5 otherwise "small"') and ':' in to_js('x = 10\ny = "big" if x > 5 otherwise "small"'))

# --- Break / Continue ---
check("break_stmt", lambda: 'break;' in to_js('While true\n  Break\nEnd'))
check("continue_stmt", lambda: 'continue;' in to_js('For i from 1 to 10\n  Continue\nEnd'))

# --- Try / Catch ---
js_tc = to_js('Try\n  Print 42\nCatch e\n  Print e\nEnd')
check("try_catch", lambda: 'try {' in js_tc and 'catch' in js_tc)

# --- Throw ---
check("throw_stmt", lambda: 'throw' in to_js('Throw "oops"'))

# --- Match / When ---
js_match = to_js('x = 2\nMatch x\n  When 1\n    Print "one"\n  When 2\n    Print "two"\nEnd')
check("match_switch", lambda: 'switch' in js_match or 'if' in js_match)

# --- Enum ---
js_enum = to_js('Enum Color as RED, GREEN, BLUE')
check("enum_object", lambda: 'Color' in js_enum and 'RED' in js_enum)

# --- Classes ---
js_class = to_js('Class Dog\n  name = "Rex"\n  Function speak\n    Print "Woof"\n  End\nEnd')
check("class_def", lambda: 'class Dog' in js_class or 'Dog' in js_class)

# --- Constants ---
check("const_decl", lambda: 'const' in to_js('Constant PI = 3.14'))

# --- Assert ---
check("assert_stmt", lambda: 'assert' in to_js('Assert 1 == 1').lower() or 'throw' in to_js('Assert 1 == 1').lower() or 'if' in to_js('Assert 1 == 1'))

# --- Node.js target ---
node_out = to_node('Print "Hello"')
check("node_has_header", lambda: 'Node.js target' in node_out)
check("node_has_console", lambda: 'console.log("Hello")' in node_out)

# --- Lambda ---
check("lambda_expr", lambda: '=>' in to_js('double = lambda x -> x * 2'))

# --- Import ---
check("import_comment", lambda: '// import:' in to_js('Import "helper.epl"') or 'import' in to_js('Import "helper.epl"').lower())

print(f"\n=== JS Transpiler Results: {passed}/{passed+failed} passed, {failed} failed ===")

if failed > 0:
    sys.exit(1)
