"""
Real ASGI Integration Test — runs uvicorn with the ASGIAdapter
and makes actual HTTP requests over the wire.
"""
import sys, os, json, time, threading, subprocess, signal
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from urllib.request import urlopen, Request
from urllib.error import HTTPError
import urllib.parse

passed = 0
failed = 0

def check(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print(f"  PASS: {name}")
    else:
        failed += 1
        print(f"  FAIL: {name} {detail}")

# ═══════════════════════════════════════════════════════════
# Create a small ASGI app file that uvicorn can load
# ═══════════════════════════════════════════════════════════
ASGI_APP_CODE = '''
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from epl import ast_nodes as ast
from epl.web import EPLWebApp
from epl.deploy import ASGIAdapter

app = EPLWebApp("ASGITest")
app.cors_enabled = True
app.cors_origins = "*"
app.rate_limit = 0

app.add_route("/", "page", [
    ast.PageDef("Home", [
        ast.HtmlElement("heading", ast.Literal("ASGI Works")),
    ])
], method="GET")

app.add_route("/api/ping", "json", [
    ast.FetchStatement("pings")
], method="GET")

app.add_route("/api/ping", "action", [
    ast.StoreStatement("pings", field_name="msg"),
], method="POST")

application = ASGIAdapter(app)
'''

# Write temp asgi module
asgi_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_tmp_asgi_app.py')
with open(asgi_path, 'w') as f:
    f.write(ASGI_APP_CODE)

PORT = 19877
BASE = f'http://127.0.0.1:{PORT}'

print("\n=== Real ASGI/Uvicorn Integration Tests ===\n")

# Start uvicorn as subprocess
proc = subprocess.Popen(
    [sys.executable, '-m', 'uvicorn', '_tmp_asgi_app:application',
     '--host', '127.0.0.1', '--port', str(PORT), '--log-level', 'warning'],
    cwd=os.path.dirname(os.path.abspath(__file__)),
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
)

# Wait for server to start
server_ready = False
for _ in range(30):  # up to 3 seconds
    time.sleep(0.1)
    try:
        urlopen(f"{BASE}/_health", timeout=2)
        server_ready = True
        break
    except Exception:
        continue

if not server_ready:
    print("  FAIL: Uvicorn server did not start in time")
    stderr = proc.stderr.read().decode() if proc.stderr else ""
    print(f"  stderr: {stderr[:500]}")
    proc.terminate()
    os.remove(asgi_path)
    sys.exit(1)

print("--- Uvicorn Server Started ---")

try:
    # 1. Health check
    resp = urlopen(f"{BASE}/_health", timeout=5)
    data = json.loads(resp.read())
    check("ASGI health returns 200", resp.status == 200)
    check("ASGI health is healthy", data["status"] == "healthy")
    check("ASGI health has wsgi flag", data.get("wsgi") is True)

    # 2. Page route
    resp = urlopen(f"{BASE}/", timeout=5)
    html = resp.read().decode("utf-8")
    check("ASGI page returns 200", resp.status == 200)
    check("ASGI page has heading", "ASGI Works" in html, f"got: {html[:200]}")
    check("ASGI page Content-Type", "text/html" in resp.headers.get("Content-Type", ""))

    # 3. JSON route
    resp = urlopen(f"{BASE}/api/ping", timeout=5)
    data = json.loads(resp.read())
    check("ASGI JSON returns 200", resp.status == 200)
    check("ASGI JSON Content-Type", "application/json" in resp.headers.get("Content-Type", ""))
    check("ASGI JSON has collection", "collection" in data)

    # 4. POST action
    body = urllib.parse.urlencode({"msg": "hello-asgi"}).encode()
    req = Request(f"{BASE}/api/ping", data=body, method="POST",
                  headers={"Content-Type": "application/x-www-form-urlencoded"})
    resp = urlopen(req, timeout=5)
    check("ASGI POST returns 200", resp.status == 200)

    # Verify store
    resp = urlopen(f"{BASE}/api/ping", timeout=5)
    data = json.loads(resp.read())
    check("ASGI store has item", data.get("count", 0) >= 1, f"got: {data}")

    # 5. 404
    try:
        urlopen(f"{BASE}/does-not-exist", timeout=5)
        check("ASGI 404", False)
    except HTTPError as e:
        check("ASGI 404 for unknown route", e.code == 404)

    # 6. CORS preflight
    req = Request(f"{BASE}/anything", method="OPTIONS")
    resp = urlopen(req, timeout=5)
    check("ASGI CORS OPTIONS returns 200", resp.status == 200)
    check("ASGI CORS Allow-Origin", resp.headers.get("Access-Control-Allow-Origin") == "*")

    # 7. Security headers
    resp = urlopen(f"{BASE}/_health", timeout=5)
    resp.read()
    check("ASGI X-Content-Type-Options", resp.headers.get("X-Content-Type-Options") == "nosniff")
    check("ASGI X-Frame-Options", resp.headers.get("X-Frame-Options") == "SAMEORIGIN")

    # 8. JSON POST
    body = json.dumps({"msg": "json-asgi"}).encode()
    req = Request(f"{BASE}/api/ping", data=body, method="POST",
                  headers={"Content-Type": "application/json"})
    resp = urlopen(req, timeout=5)
    check("ASGI JSON POST returns 200", resp.status == 200)

    # 9. Query string
    resp = urlopen(f"{BASE}/_health?check=true", timeout=5)
    data = json.loads(resp.read())
    check("ASGI query string works", data["status"] == "healthy")

    # 10. Concurrent
    from concurrent.futures import ThreadPoolExecutor
    def fetch(_):
        resp = urlopen(f"{BASE}/", timeout=5)
        resp.read()
        return resp.status
    with ThreadPoolExecutor(max_workers=10) as ex:
        results = list(ex.map(fetch, range(20)))
    ok = sum(1 for r in results if r == 200)
    check(f"ASGI 20 concurrent requests ({ok}/20)", ok == 20)

finally:
    proc.terminate()
    proc.wait(timeout=5)
    if os.path.exists(asgi_path):
        os.remove(asgi_path)

print(f"\n{'='*50}")
print(f"  ASGI/Uvicorn Tests: {passed}/{passed+failed} passed, {failed} failed")
if failed == 0:
    print("  All tests passed!")
else:
    print(f"  {failed} test(s) FAILED")
print(f"{'='*50}\n")

if __name__ == '__main__':
    sys.exit(1 if failed else 0)
