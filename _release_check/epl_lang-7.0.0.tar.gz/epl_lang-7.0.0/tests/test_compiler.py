"""
Tests for EPL LLVM Compiler (epl/compiler.py)
Validates that EPL source → LLVM IR generation works correctly.
Tests IR structure, not execution (since that requires linking).
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

passed = 0
failed = 0

def check(name, fn):
    global passed, failed
    try:
        result = fn()
        if result:
            print(f"  PASS: {name}")
            passed += 1
        else:
            print(f"  FAIL: {name}")
            failed += 1
    except Exception as e:
        print(f"  FAIL: {name} — {e}")
        failed += 1


def compile_to_ir(src):
    """Parse EPL source and compile to LLVM IR string."""
    from epl.lexer import Lexer
    from epl.parser import Parser
    from epl.compiler import Compiler
    tokens = Lexer(src).tokenize()
    program = Parser(tokens).parse()
    compiler = Compiler()
    compiler.compile(program)
    return str(compiler.module)


# ─── Dependency Check ─────────────────────────────────────
try:
    import llvmlite  # type: ignore[reportMissingImports]
    HAS_LLVM = True
except ImportError:
    HAS_LLVM = False
    print("SKIP: llvmlite not installed — compiler tests skipped.")

if HAS_LLVM:
    print("=== Compiler Tests (LLVM IR generation) ===\n")

    # --- Basic IR Generation ---
    check("ir_generates", lambda: len(compile_to_ir('Print 42')) > 0)
    check("ir_has_main", lambda: 'define i32 @"main"()' in compile_to_ir('Print 42'))

    # --- Print Statements ---
    check("print_int", lambda: 'printf' in compile_to_ir('Print 42'))
    check("print_string", lambda: 'Hello' in compile_to_ir('Print "Hello"'))
    check("print_float", lambda: 'printf' in compile_to_ir('Print 3.14'))

    # --- Variables ---
    check("var_decl_int", lambda: 'alloca i64' in compile_to_ir('x = 42\nPrint x'))
    check("var_decl_str", lambda: 'alloca i8*' in compile_to_ir('name = "Alice"\nPrint name'))
    check("var_assign", lambda: 'store' in compile_to_ir('x = 1\nSet x to 2'))
    check("var_float", lambda: 'double' in compile_to_ir('pi = 3.14'))

    # --- Arithmetic ---
    check("arith_add", lambda: 'add' in compile_to_ir('Print 3 + 4'))
    check("arith_sub", lambda: 'sub' in compile_to_ir('Print 10 - 5'))
    check("arith_mul", lambda: 'mul' in compile_to_ir('Print 6 * 7'))
    check("arith_div", lambda: 'sdiv' in compile_to_ir('Print 10 / 2'))
    check("arith_mod", lambda: 'srem' in compile_to_ir('Print 10 % 3'))
    check("arith_power", lambda: 'epl_power' in compile_to_ir('Print 2 ** 3'))
    check("arith_floor_div", lambda: 'epl_floor' in compile_to_ir('Print 7 // 2'))

    # --- Comparisons ---
    check("cmp_gt", lambda: 'icmp sgt' in compile_to_ir('Print 5 > 3'))
    check("cmp_lt", lambda: 'icmp slt' in compile_to_ir('Print 3 < 5'))
    check("cmp_eq", lambda: 'icmp eq' in compile_to_ir('Print 5 == 5'))
    check("cmp_ne", lambda: 'icmp ne' in compile_to_ir('Print 5 != 3'))

    # --- Conditionals ---
    check("if_then", lambda: 'br i1' in compile_to_ir('If 5 > 3 then\n  Print "yes"\nEnd'))
    check("if_else", lambda: compile_to_ir('If 1 > 2 then\n  Print "a"\nOtherwise\n  Print "b"\nEnd').count('br ') >= 2)

    # --- Loops ---
    check("while_loop", lambda: 'br i1' in compile_to_ir('x = 0\nWhile x < 5\n  Print x\n  x += 1\nEnd'))
    check("repeat_loop", lambda: 'br i1' in compile_to_ir('Repeat 3 times\n  Print "hi"\nEnd'))
    check("for_range", lambda: 'br i1' in compile_to_ir('For i from 1 to 5\n  Print i\nEnd'))
    check("for_each_list", lambda: 'epl_list_new' in compile_to_ir('items = [1, 2, 3]\nFor each x in items\n  Print x\nEnd'))

    # --- Functions ---
    check("func_def", lambda: 'define' in compile_to_ir('Function greet\n  Print "hi"\nEnd'))
    check("func_with_params", lambda: 'epl_add' in compile_to_ir('Function add takes a and b\n  Return a + b\nEnd'))
    check("func_call", lambda: 'call' in compile_to_ir('Function greet\n  Print "hi"\nEnd\nCall greet'))

    # --- Augmented Assignment ---
    check("aug_plus", lambda: 'add' in compile_to_ir('x = 10\nx += 5'))
    check("aug_minus", lambda: 'sub' in compile_to_ir('x = 10\nx -= 3'))
    check("aug_mul", lambda: 'mul' in compile_to_ir('x = 10\nx *= 2'))

    # --- Strings ---
    check("str_concat", lambda: 'strcat' in compile_to_ir('Print "Hello" + " World"'))
    check("str_method_upper", lambda: 'epl_string_upper' in compile_to_ir('x = "hello"\nPrint x.upper()'))
    check("str_method_lower", lambda: 'epl_string_lower' in compile_to_ir('x = "HELLO"\nPrint x.lower()'))
    check("str_method_trim", lambda: 'epl_string_trim' in compile_to_ir('x = "  hi  "\nPrint x.trim()'))

    # --- Lists ---
    check("list_literal", lambda: 'epl_list_new' in compile_to_ir('items = [1, 2, 3]'))
    check("list_push", lambda: 'epl_list_push' in compile_to_ir('items = [1, 2]\nitems.add(3)'))
    check("list_length", lambda: 'epl_list_length' in compile_to_ir('items = [1, 2]\nPrint length(items)'))

    # --- Builtins ---
    check("builtin_sqrt", lambda: 'epl_sqrt' in compile_to_ir('Print sqrt(16)'))
    check("builtin_floor", lambda: 'epl_floor' in compile_to_ir('Print floor(3.7)'))
    check("builtin_ceil", lambda: 'epl_ceil' in compile_to_ir('Print ceil(3.2)'))
    check("builtin_abs", lambda: compile_to_ir('Print absolute(-5)') is not None)

    # --- Enums ---
    check("enum_def", lambda: compile_to_ir('Enum Color as RED, GREEN, BLUE') is not None)

    # --- Try/Catch ---
    ir_tc = compile_to_ir('Try\n  Print 42\nCatch e\n  Print "error"\nEnd')
    check("try_catch_has_try_block", lambda: 'try:' in ir_tc or 'try' in ir_tc)
    check("try_catch_has_catch_block", lambda: 'catch:' in ir_tc or 'catch' in ir_tc)
    check("try_catch_has_end_block", lambda: 'try_end:' in ir_tc or 'try_end' in ir_tc)

    # --- Throw ---
    check("throw_stmt", lambda: 'exit' in compile_to_ir('Throw "oops"'))

    # --- Match/When ---
    check("match_when", lambda: compile_to_ir('x = 2\nMatch x\n  When 1\n    Print "one"\n  When 2\n    Print "two"\nEnd') is not None)

    # --- Break / Continue ---
    check("break_in_while", lambda: 'br label' in compile_to_ir('x = 0\nWhile x < 10\n  If x == 5 then\n    Break\n  End\n  x += 1\nEnd'))

    # --- Constants ---
    check("const_decl", lambda: compile_to_ir('Constant PI = 3.14') is not None)

    # --- Ternary ---
    check("ternary_expr", lambda: 'select' in compile_to_ir('x = 10\ny = 1 if x > 5 otherwise 0\nPrint y') or 'phi' in compile_to_ir('x = 10\ny = 1 if x > 5 otherwise 0\nPrint y'))

    # --- Lambda ---
    check("lambda_def", lambda: compile_to_ir('double = lambda x -> x * 2') is not None)

    # --- Slicing ---
    check("slice_list", lambda: 'epl_list_slice' in compile_to_ir('items = [1, 2, 3, 4, 5]\ny = items[1:3]'))

    # --- File I/O ---
    check("file_write", lambda: compile_to_ir('Write "hello" to file "test.txt"') is not None)

    # --- v2.0: Extended Coverage ---

    # Classes & Inheritance
    check("class_def", lambda: 'epl_object_new' in compile_to_ir(
        'Class Animal\n  name = "unknown"\n  Function speak\n    Print "..."\n  End\nEnd\na = new Animal()'))
    check("class_method_call", lambda: 'call' in compile_to_ir(
        'Class Dog\n  Function bark\n    Print "woof"\n  End\nEnd\nd = new Dog()\nd.bark()'))
    check("class_inheritance", lambda: compile_to_ir(
        'Class Animal\n  name = "a"\n  Function speak\n    Print "..."\n  End\nEnd\n'
        'Class Dog extends Animal\n  Function speak\n    Print "woof"\n  End\nEnd\nd = new Dog()') is not None)
    check("class_property_set", lambda: 'epl_object_set' in compile_to_ir(
        'Class Box\n  value = 0\nEnd\nb = new Box()\nb.value = 42'))
    check("class_property_get", lambda: 'epl_object_get' in compile_to_ir(
        'Class Box\n  value = 0\nEnd\nb = new Box()\nPrint b.value'))

    # Dict operations
    check("dict_literal", lambda: 'epl_map_new' in compile_to_ir('d = Map with a = 1 and b = 2'))

    # Modules
    check("module_def", lambda: 'epl_Math_square' in compile_to_ir(
        'Module Math\n  Function square takes x\n    Return x * x\n  End\nEnd\nPrint Math::square(5)'))

    # For each on string
    check("for_each_string", lambda: 'epl_string_index' in compile_to_ir(
        's = "abc"\nFor each ch in s\n  Print ch\nEnd'))

    # Destructuring
    # Destructuring (parser doesn't have this syntax; AST-only feature)
    # check("destructure", ...) — requires parser extension

    # Chained comparison (parser doesn't produce ChainedComparison; AST-only)
    # check("chained_cmp", ...) — requires parser extension

    # Async compiled as sync
    check("async_function", lambda: 'epl_fetch' in compile_to_ir(
        'Async Function fetch_data\n  Return 42\nEnd\nPrint fetch_data()'))

    # String methods extended
    check("str_contains", lambda: 'epl_string_contains' in compile_to_ir(
        's = "hello world"\nPrint s.contains("world")'))
    check("str_replace", lambda: 'epl_string_replace' in compile_to_ir(
        's = "hello"\nPrint s.replace("he", "HE")'))
    check("str_starts_with", lambda: 'epl_string_starts_with' in compile_to_ir(
        's = "hello"\nPrint s.starts_with("he")'))
    check("str_ends_with", lambda: 'epl_string_ends_with' in compile_to_ir(
        's = "hello"\nPrint s.ends_with("lo")'))
    check("str_reverse", lambda: 'epl_string_reverse' in compile_to_ir(
        's = "hello"\nPrint s.reverse()'))
    check("str_split", lambda: 'epl_string_split' in compile_to_ir(
        's = "a,b,c"\nPrint s.split(",")'))
    check("str_substring", lambda: 'epl_string_substring' in compile_to_ir(
        's = "hello"\nPrint s.substring(0, 3)'))
    check("str_length_method", lambda: 'epl_string_length' in compile_to_ir(
        's = "hello"\nPrint s.length()'))

    # List methods
    check("list_remove", lambda: 'epl_list_remove' in compile_to_ir(
        'items = [1, 2, 3]\nitems.remove(1)'))
    check("list_contains", lambda: 'epl_list_contains' in compile_to_ir(
        'items = [1, 2, 3]\nr = items.contains(2)\nPrint r'))
    check("list_index_set", lambda: 'epl_list_set_int' in compile_to_ir(
        'items = [1, 2, 3]\nitems[0] = 99'))

    # Float operations
    check("float_add", lambda: 'fadd' in compile_to_ir('Print 1.5 + 2.5'))
    check("float_sub", lambda: 'fsub' in compile_to_ir('Print 5.0 - 2.0'))
    check("float_mul", lambda: 'fmul' in compile_to_ir('Print 2.0 * 3.0'))
    check("float_div", lambda: 'fdiv' in compile_to_ir('Print 10.0 / 3.0'))
    check("float_cmp", lambda: 'fcmp ogt' in compile_to_ir('Print 3.14 > 2.71'))

    # Bool operations
    check("bool_true", lambda: compile_to_ir('x = true\nPrint x') is not None)
    check("bool_false", lambda: compile_to_ir('x = false\nPrint x') is not None)
    check("bool_not", lambda: compile_to_ir('x = not true\nPrint x') is not None)

    # Builtin type conversions
    check("to_integer", lambda: 'epl_string_to_int' in compile_to_ir('Print to_integer("42")'))
    check("to_text", lambda: 'epl_int_to_string' in compile_to_ir('Print to_text(42)'))
    check("to_decimal", lambda: compile_to_ir('Print to_decimal(42)') is not None)

    # Builtins extended
    check("builtin_log", lambda: 'epl_log' in compile_to_ir('Print log(100)'))
    check("builtin_sin", lambda: 'epl_sin' in compile_to_ir('Print sin(0)'))
    check("builtin_cos", lambda: 'epl_cos' in compile_to_ir('Print cos(0)'))
    check("builtin_max", lambda: compile_to_ir('Print max(3, 7)') is not None)
    check("builtin_min", lambda: compile_to_ir('Print min(3, 7)') is not None)
    check("builtin_round", lambda: compile_to_ir('Print round(3.7)') is not None)
    check("builtin_char_code", lambda: compile_to_ir('Print char_code("A")') is not None)
    check("builtin_from_char_code", lambda: compile_to_ir('Print from_char_code(65)') is not None)

    # Memory management
    check("arena_reset_emitted", lambda: 'epl_arena_reset' in compile_to_ir('Print "hello"'))

    # Try/Catch/Finally
    # Try with finally block (parser produces TryCatch, not TryCatchFinally for basic syntax)
    check("try_catch_finally", lambda: 'epl_try_begin' in compile_to_ir(
        'Try\n  Print "try"\nCatch e\n  Print e\nFinally\n  Print "done"\nEnd'))

    # Recursion
    check("recursive_func", lambda: 'epl_fib' in compile_to_ir(
        'Function fib takes n\n  If n <= 1 then\n    Return n\n  End\n  Return fib(n - 1) + fib(n - 2)\nEnd\nPrint fib(10)'))

    # Complex expressions
    check("nested_func_calls", lambda: compile_to_ir(
        'Function double takes x\n  Return x * 2\nEnd\n'
        'Function square takes x\n  Return x * x\nEnd\n'
        'Print double(square(3))') is not None)

    # Object code generation
    try:
        import llvmlite.binding as _llvm  # type: ignore[reportMissingImports]
        ir_code = compile_to_ir('Print 42')
        mod = _llvm.parse_assembly(ir_code)
        mod.verify()
        target = _llvm.Target.from_default_triple()
        tm = target.create_target_machine(opt=2, reloc='pic', codemodel='default')
        obj = tm.emit_object(mod)
        check("object_code_gen", lambda: len(obj) > 0)
    except Exception as e:
        check("object_code_gen", lambda: False)

    print(f"\n=== Compiler Results: {passed}/{passed+failed} passed, {failed} failed ===")
else:
    print("Compiler tests require llvmlite. Install with: pip install llvmlite")

if failed > 0:
    sys.exit(1)
