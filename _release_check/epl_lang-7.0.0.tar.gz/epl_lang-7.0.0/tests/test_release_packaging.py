"""Release-tooling regression tests for packaging and import surfaces."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import unittest
import zipfile
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
RELEASE_ENV_VAR = "EPL_RUN_RELEASE_TESTS"


class TestReleasePackaging(unittest.TestCase):
    def test_public_api_exports_are_lazy(self):
        script = (
            "import sys, epl; "
            "print(int('epl.interpreter' in sys.modules)); "
            "_ = epl.Interpreter; "
            "print(int('epl.interpreter' in sys.modules))"
        )
        result = subprocess.run(
            [sys.executable, "-c", script],
            cwd=REPO_ROOT,
            capture_output=True,
            text=True,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip().splitlines(), ["0", "1"])

    @unittest.skipUnless(
        os.environ.get(RELEASE_ENV_VAR) == "1",
        f"set {RELEASE_ENV_VAR}=1 to run release build checks",
    )
    def test_python_build_includes_runtime_assets(self):
        outdir = Path(tempfile.mkdtemp(prefix="epl_release_dist_"))
        try:
            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "build",
                    "--wheel",
                    "--sdist",
                    "--outdir",
                    str(outdir),
                ],
                cwd=REPO_ROOT,
                capture_output=True,
                text=True,
            )
            build_output = result.stdout + "\n" + result.stderr
            self.assertEqual(result.returncode, 0, build_output)

            wheel_path = next(outdir.glob("*.whl"), None)
            sdist_path = next(outdir.glob("*.tar.gz"), None)
            self.assertIsNotNone(wheel_path, build_output)
            self.assertIsNotNone(sdist_path, build_output)

            with zipfile.ZipFile(wheel_path) as wheel_zip:
                wheel_names = set(wheel_zip.namelist())

            required_wheel_files = {
                "epl/registry.json",
                "epl/runtime.c",
                "epl/models/Modelfile",
                "epl/stdlib/math.epl",
                "epl/stdlib/registry.json",
            }
            self.assertTrue(
                required_wheel_files.issubset(wheel_names),
                sorted(required_wheel_files - wheel_names),
            )

            with tarfile.open(sdist_path, "r:gz") as sdist_tar:
                sdist_names = set(sdist_tar.getnames())

            prefix = next(name.split("/", 1)[0] for name in sdist_names if name.endswith("PKG-INFO"))
            required_sdist_suffixes = {
                "MANIFEST.in",
                "bundle.py",
                "epl/registry.json",
                "epl/runtime.c",
                "epl/models/Modelfile",
                "epl/stdlib/math.epl",
                "epl/stdlib/registry.json",
            }
            missing = sorted(
                suffix for suffix in required_sdist_suffixes if f"{prefix}/{suffix}" not in sdist_names
            )
            self.assertEqual(missing, [], missing)
        finally:
            shutil.rmtree(outdir, ignore_errors=True)
            shutil.rmtree(REPO_ROOT / "build", ignore_errors=True)
            for egg_info in REPO_ROOT.glob("*.egg-info"):
                shutil.rmtree(egg_info, ignore_errors=True)
