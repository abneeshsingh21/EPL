"""Regression tests for the production-facing CLI and packager paths."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from epl.cli import cli_main
from epl.package_manager import save_manifest
from epl.packager import BuildConfig


def _write_manifest(project_dir: str, entry: str = "src/main.epl") -> None:
    manifest = {
        "name": "demo",
        "version": "1.0.0",
        "description": "demo project",
        "author": "",
        "entry": entry,
        "dependencies": {},
        "scripts": {},
    }
    save_manifest(manifest, project_dir, fmt="toml")


class TestCLIProduction(unittest.TestCase):
    def test_run_strict_uses_current_typechecker_api(self):
        with tempfile.TemporaryDirectory(prefix="epl_cli_strict_") as tmpdir:
            source = Path(tmpdir) / "hello.epl"
            source.write_text('Say "Hello strict"\n', encoding="utf-8")

            result = subprocess.run(
                [sys.executable, "-m", "epl", "run", str(source), "--strict"],
                capture_output=True,
                text=True,
                cwd=os.getcwd(),
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("Hello strict", result.stdout)

    def test_run_sandbox_blocks_file_write(self):
        with tempfile.TemporaryDirectory(prefix="epl_cli_sandbox_") as tmpdir:
            output = Path(tmpdir) / "wrote.txt"
            source = Path(tmpdir) / "write.epl"
            source.write_text(
                f'Write "blocked" to file "{output.as_posix()}"\n',
                encoding="utf-8",
            )

            result = subprocess.run(
                [sys.executable, "-m", "epl", "run", str(source), "--sandbox"],
                capture_output=True,
                text=True,
                cwd=os.getcwd(),
            )

            self.assertNotEqual(result.returncode, 0)
            self.assertFalse(output.exists())
            self.assertIn("safe mode", result.stderr.lower())

    def test_build_defaults_to_manifest_entrypoint(self):
        tmpdir = tempfile.mkdtemp(prefix="epl_cli_build_")
        old_cwd = os.getcwd()
        old_argv = sys.argv[:]
        try:
            os.chdir(tmpdir)
            os.makedirs("src", exist_ok=True)
            Path("src/main.epl").write_text('Say "Hello build"\n', encoding="utf-8")
            _write_manifest(tmpdir, entry="src/main.epl")

            with mock.patch("main.main", return_value=None) as main_entry:
                exit_code = cli_main(["build"])

            self.assertEqual(exit_code, 0)
            self.assertTrue(main_entry.called)
            self.assertEqual(sys.argv[:3], ["epl", "compile", "src/main.epl"])
        finally:
            sys.argv = old_argv
            os.chdir(old_cwd)
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_packager_reads_toml_project_manifest(self):
        with tempfile.TemporaryDirectory(prefix="epl_packager_toml_") as tmpdir:
            os.makedirs(os.path.join(tmpdir, "src"), exist_ok=True)
            Path(tmpdir, "src", "main.epl").write_text('Say "Hello package"\n', encoding="utf-8")
            _write_manifest(tmpdir, entry="src/main.epl")

            config = BuildConfig.from_epl_project(tmpdir)

            self.assertTrue(config.source_file.endswith(os.path.join("src", "main.epl")))
            self.assertEqual(config.output_name, "demo")
            self.assertEqual(config.version, "1.0.0")
